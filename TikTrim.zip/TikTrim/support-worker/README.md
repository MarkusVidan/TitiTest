# Сервер для чата с разработчиком (Cloudflare Worker, бесплатно)

Приложение не хранит токен бота: он лежит только здесь, в секретах Worker.

## Настройка (можно с телефона)
1. Зайди на dash.cloudflare.com, зарегистрируйся, открой **Workers & Pages → Create → Create Worker**.
   Назови, например, `tiktrim-support`, нажми **Deploy**, затем **Edit code**: удали всё и вставь содержимое `worker.js`, нажми **Deploy**.
2. **Storage & Databases → KV → Create** (имя любое, например `chat`). Вернись в Worker: **Settings → Bindings → Add → KV namespace**, переменная **CHAT**, выбери созданное хранилище.
3. **Settings → Variables and Secrets → Add**:
   - `BOT_TOKEN` (тип Secret): токен бота;
   - `WEBHOOK_SECRET` (Secret): любая случайная строка из букв и цифр, например `k8Jd92LmQ4xZ`;
   - `ADMIN_ID` (Text): добавишь на шаге 5.
4. Подключи webhook: открой в браузере (подставь свои значения)
   `https://api.telegram.org/bot<ТОКЕН>/setWebhook?url=https://<адрес-worker>/tg&secret_token=<WEBHOOK_SECRET>`
   В ответе должно быть `"ok":true`.
5. Напиши своему боту `/id`: он пришлёт число. Добавь его в переменную `ADMIN_ID` и нажми **Deploy**.
6. В приложении в файле `Support.kt` замени `https://YOUR-WORKER.workers.dev` на адрес твоего Worker и собери новую версию.

## Как пользоваться
Пользователь пишет в приложении, а бот присылает тебе сообщение вида `#a1b2c3 v5.4 · Android 14 · …`.
Чтобы ответить, нажми **Reply** на это сообщение бота: ответ придёт в приложение, а бот напишет «✓ Доставлено».
