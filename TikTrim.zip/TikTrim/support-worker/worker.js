// TikTrim support relay for Cloudflare Workers.
// Приложение <-> этот сервер <-> Telegram-бот. Токен бота лежит ТОЛЬКО здесь (в секретах Worker).
//
// Переменные и секреты (Settings -> Variables and Secrets):
//   BOT_TOKEN       (secret) токен бота от @BotFather
//   WEBHOOK_SECRET  (secret) любая случайная строка из букв и цифр
//   ADMIN_ID        (text)   числовой id вашего Telegram-аккаунта (узнать: написать боту /id)
// KV-хранилище: привязка с именем CHAT.

const TTL = 60 * 60 * 24 * 90; // 90 дней

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json; charset=utf-8' } });

const validUid = (u) => typeof u === 'string' && /^[a-f0-9]{32}$/.test(u);

async function tgApi(env, method, body) {
  const r = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return r.json();
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    try {
      if (url.pathname === '/send' && req.method === 'POST') return await send(req, env);
      if (url.pathname === '/poll' && req.method === 'GET') return await poll(url, env);
      if (url.pathname === '/tg' && req.method === 'POST') return await telegram(req, env);
      return json({ ok: true, service: 'tiktrim-support' });
    } catch (e) {
      return json({ ok: false, error: String(e) }, 500);
    }
  },
};

// Сообщение от пользователя -> в Telegram разработчику
async function send(req, env) {
  const b = await req.json();
  const text = String(b.text || '').trim().slice(0, 1000);
  if (!validUid(b.uid) || !text) return json({ ok: false, error: 'bad request' }, 400);

  // не больше 30 сообщений в час с одной установки
  const rlKey = `rl:${b.uid}`;
  const n = parseInt((await env.CHAT.get(rlKey)) || '0', 10);
  if (n >= 30) return json({ ok: false, error: 'rate limit' }, 429);
  await env.CHAT.put(rlKey, String(n + 1), { expirationTtl: 3600 });

  const info = String(b.info || '').slice(0, 200);
  const r = await tgApi(env, 'sendMessage', {
    chat_id: env.ADMIN_ID,
    text: `#${b.uid.slice(0, 6)}  ${info}\n\n${text}`,
  });
  if (!r.ok) return json({ ok: false, error: 'telegram' }, 502);
  await env.CHAT.put(`m:${r.result.message_id}`, b.uid, { expirationTtl: TTL });
  return json({ ok: true });
}

// Приложение спрашивает, нет ли ответов
async function poll(url, env) {
  const uid = url.searchParams.get('uid');
  const after = parseInt(url.searchParams.get('after') || '0', 10);
  if (!validUid(uid)) return json({ ok: false, error: 'bad request' }, 400);
  const arr = JSON.parse((await env.CHAT.get(`in:${uid}`)) || '[]');
  return json({ ok: true, msgs: arr.filter((m) => m.id > after) });
}

// Webhook Telegram: ответ разработчика (Reply на сообщение бота) -> пользователю
async function telegram(req, env) {
  if (req.headers.get('X-Telegram-Bot-Api-Secret-Token') !== env.WEBHOOK_SECRET) {
    return new Response('forbidden', { status: 401 });
  }
  const update = await req.json();
  const msg = update.message;
  if (!msg || !msg.from) return json({ ok: true });

  if ((msg.text || '').trim() === '/id') {
    await tgApi(env, 'sendMessage', { chat_id: msg.chat.id, text: `Your id: ${msg.chat.id}` });
    return json({ ok: true });
  }
  if (String(msg.from.id) !== String(env.ADMIN_ID)) return json({ ok: true });

  const rt = msg.reply_to_message;
  if (!rt || !msg.text) {
    await tgApi(env, 'sendMessage', {
      chat_id: msg.chat.id,
      text: 'Ответь (Reply) на сообщение пользователя, чтобы ответить ему.',
    });
    return json({ ok: true });
  }
  const uid = await env.CHAT.get(`m:${rt.message_id}`);
  if (!uid) {
    await tgApi(env, 'sendMessage', {
      chat_id: msg.chat.id,
      text: 'Не нашёл, кому это адресовано (сообщение старше 90 дней?).',
      reply_to_message_id: msg.message_id,
    });
    return json({ ok: true });
  }
  const seq = parseInt((await env.CHAT.get(`seq:${uid}`)) || '0', 10) + 1;
  const arr = JSON.parse((await env.CHAT.get(`in:${uid}`)) || '[]');
  arr.push({ id: seq, text: msg.text.slice(0, 2000), ts: Date.now() });
  await env.CHAT.put(`in:${uid}`, JSON.stringify(arr.slice(-100)), { expirationTtl: TTL });
  await env.CHAT.put(`seq:${uid}`, String(seq), { expirationTtl: TTL });
  await tgApi(env, 'sendMessage', {
    chat_id: msg.chat.id, text: '✓ Доставлено', reply_to_message_id: msg.message_id,
  });
  return json({ ok: true });
}
