plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ytdl = "0.18.1"   // обёртка yt-dlp для Android (Maven Central)

android {
    namespace = "com.example.tiktrim"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tiktrim"
        minSdk = 29
        targetSdk = 34
        versionCode = 12
        versionName = "5.4"

        // Только 64-битные телефоны (почти все современные). Так APK втрое легче.
        // Если нужен и старый 32-битный: добавь "armeabi-v7a" в список.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // yt-dlp и ffmpeg лежат в нативных библиотеках, их нужно распаковывать
    packaging { jniLibs { useLegacyPackaging = true } }

    // Подпись релиза: данные берутся из переменных окружения (GitHub Actions) или не используются
    val ksPath = System.getenv("KEYSTORE_PATH")
    if (ksPath != null) {
        signingConfigs {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("STORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            if (ksPath != null) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-Xskip-metadata-version-check"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
}
