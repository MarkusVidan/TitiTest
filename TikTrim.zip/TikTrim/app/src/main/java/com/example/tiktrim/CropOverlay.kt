package com.example.tiktrim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Рамка кадрирования, которую двигают и тянут пальцем.
 * Если задан lockedAspect > 0, пропорции рамки фиксированы (тянуть можно за углы).
 * Если 0 — рамка свободная (тянуть можно за углы и за стороны).
 */
class CropOverlay @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var onChanged: (() -> Unit)? = null
    var onUserEdit: (() -> Unit)? = null
    var onTap: (() -> Unit)? = null

    var lockedAspect = 0f
        private set

    private var vw = 0
    private var vh = 0
    /** Рамка в долях видео: 0..1, от левого верхнего угла. */
    private val crop = RectF(0f, 0f, 1f, 1f)

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val dim = Paint().apply { color = 0xB3000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2 * d
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66FFFFFF; style = Paint.Style.STROKE; strokeWidth = 1 * d
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF25F4EE.toInt(); style = Paint.Style.STROKE
        strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND
    }

    // ---------- Управление из активности ----------

    fun setVideo(w: Int, h: Int) {
        vw = w; vh = h
        crop.set(0f, 0f, 1f, 1f)
        changed()
    }

    /** Вся картинка, рамка свободная. */
    fun setFull() {
        lockedAspect = 0f
        crop.set(0f, 0f, 1f, 1f)
        changed()
    }

    /** Свободная рамка: оставляем как есть, снимаем фиксацию пропорций. */
    fun setFree() {
        lockedAspect = 0f
        invalidate()
    }

    /** Фиксированные пропорции (ширина / высота), рамка максимального размера по центру. */
    fun setAspect(a: Float) {
        lockedAspect = a
        if (vw == 0 || vh == 0 || a <= 0f) return
        var pw = vw.toFloat()
        var ph = pw / a
        if (ph > vh) { ph = vh.toFloat(); pw = ph * a }
        val nw = pw / vw
        val nh = ph / vh
        crop.set((1 - nw) / 2, (1 - nh) / 2, (1 + nw) / 2, (1 + nh) / 2)
        changed()
    }

    /** x, y, ширина, высота в пикселях видео; все значения чётные (нужно кодеку). */
    fun cropPixels(): IntArray {
        if (vw == 0 || vh == 0) return intArrayOf(0, 0, 0, 0)
        fun ev(v: Float) = (v.roundToInt() / 2) * 2
        val x0 = ev(crop.left * vw).coerceIn(0, vw)
        var x1 = ev(crop.right * vw).coerceIn(0, vw)
        val y0 = ev(crop.top * vh).coerceIn(0, vh)
        var y1 = ev(crop.bottom * vh).coerceIn(0, vh)
        if (x1 - x0 < 2) x1 = min(vw, x0 + 2)
        if (y1 - y0 < 2) y1 = min(vh, y0 + 2)
        return intArrayOf(x0, y0, x1 - x0, y1 - y0)
    }

    fun isFull(): Boolean {
        val c = cropPixels()
        return c[0] == 0 && c[1] == 0 && c[2] >= vw - 1 && c[3] >= vh - 1
    }

    private fun changed() {
        invalidate()
        onChanged?.invoke()
    }

    // ---------- Геометрия ----------

    private fun disp(): RectF {
        val s = min(width.toFloat() / vw, height.toFloat() / vh)
        val w = vw * s
        val h = vh * s
        val l = (width - w) / 2
        val t = (height - h) / 2
        return RectF(l, t, l + w, t + h)
    }

    private fun toView(b: RectF) = RectF(
        b.left + crop.left * b.width(), b.top + crop.top * b.height(),
        b.left + crop.right * b.width(), b.top + crop.bottom * b.height()
    )

    private fun store(r: RectF, b: RectF) {
        crop.set(
            ((r.left - b.left) / b.width()).coerceIn(0f, 1f),
            ((r.top - b.top) / b.height()).coerceIn(0f, 1f),
            ((r.right - b.left) / b.width()).coerceIn(0f, 1f),
            ((r.bottom - b.top) / b.height()).coerceIn(0f, 1f)
        )
    }

    // ---------- Рисование ----------

    override fun onDraw(c: Canvas) {
        if (vw == 0 || vh == 0 || width == 0) return
        val b = disp()
        val r = toView(b)

        c.drawRect(b.left, b.top, b.right, r.top, dim)
        c.drawRect(b.left, r.bottom, b.right, b.bottom, dim)
        c.drawRect(b.left, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, b.right, r.bottom, dim)

        // сетка третей
        for (i in 1..2) {
            val x = r.left + r.width() * i / 3
            val y = r.top + r.height() * i / 3
            c.drawLine(x, r.top, x, r.bottom, grid)
            c.drawLine(r.left, y, r.right, y, grid)
        }
        c.drawRect(r, border)

        // уголки
        val l = min(24 * d, min(r.width(), r.height()) / 3)
        val p = Path()
        fun corner(x: Float, y: Float, sx: Float, sy: Float) {
            p.moveTo(x, y + sy * l); p.lineTo(x, y); p.lineTo(x + sx * l, y)
        }
        corner(r.left, r.top, 1f, 1f)
        corner(r.right, r.top, -1f, 1f)
        corner(r.left, r.bottom, 1f, -1f)
        corner(r.right, r.bottom, -1f, -1f)
        c.drawPath(p, handle)

        // метки на сторонах (только в свободном режиме)
        if (lockedAspect == 0f) {
            val m = min(14 * d, min(r.width(), r.height()) / 6)
            val cx = r.centerX(); val cy = r.centerY()
            c.drawLine(cx - m, r.top, cx + m, r.top, handle)
            c.drawLine(cx - m, r.bottom, cx + m, r.bottom, handle)
            c.drawLine(r.left, cy - m, r.left, cy + m, handle)
            c.drawLine(r.right, cy - m, r.right, cy + m, handle)
        }
    }

    // ---------- Касания ----------

    private var mode = 0 // 0 — ничего, 1 — двигаем, 2 — тянем
    private var hl = false
    private var ht = false
    private var hr = false
    private var hb = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false

    private fun pick(x: Float, y: Float) {
        mode = 0; hl = false; ht = false; hr = false; hb = false
        val r = toView(disp())
        val s = 32 * d
        if (x < r.left - s || x > r.right + s || y < r.top - s || y > r.bottom + s) return
        val dl = abs(x - r.left); val dr = abs(x - r.right)
        val dt = abs(y - r.top); val db = abs(y - r.bottom)
        val nl = dl < s && dl <= dr
        val nr = dr < s && dr < dl
        val nt = dt < s && dt <= db
        val nb = db < s && db < dt
        val corner = (nl || nr) && (nt || nb)
        val edge = nl || nr || nt || nb
        when {
            corner || (edge && lockedAspect == 0f) -> {
                mode = 2; hl = nl; hr = nr; ht = nt; hb = nb
            }
            r.contains(x, y) -> mode = 1
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (vw == 0 || vh == 0 || width == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                moved = false
                pick(e.x, e.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) {
                    moved = true
                    if (mode != 0) onUserEdit?.invoke()
                }
                if (moved && mode != 0) {
                    apply(e.x, e.y)
                    lastX = e.x; lastY = e.y
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) onTap?.invoke()
                mode = 0
                return true
            }
            MotionEvent.ACTION_CANCEL -> { mode = 0; return true }
        }
        return super.onTouchEvent(e)
    }

    private fun apply(x: Float, y: Float) {
        val b = disp()
        val r = toView(b)
        val minS = min(72 * d, min(b.width(), b.height()))

        if (mode == 1) {
            val dx = (x - lastX).coerceIn(b.left - r.left, b.right - r.right)
            val dy = (y - lastY).coerceIn(b.top - r.top, b.bottom - r.bottom)
            r.offset(dx, dy)
        } else if (lockedAspect == 0f) {
            val dx = x - lastX
            val dy = y - lastY
            if (hl) r.left = (r.left + dx).coerceIn(b.left, max(b.left, r.right - minS))
            if (hr) r.right = (r.right + dx).coerceIn(min(b.right, r.left + minS), b.right)
            if (ht) r.top = (r.top + dy).coerceIn(b.top, max(b.top, r.bottom - minS))
            if (hb) r.bottom = (r.bottom + dy).coerceIn(min(b.bottom, r.top + minS), b.bottom)
        } else {
            // фиксированные пропорции: противоположный угол неподвижен
            val a = lockedAspect
            val ax = if (hl) r.right else r.left
            val ay = if (ht) r.bottom else r.top
            val fx = x.coerceIn(b.left, b.right)
            val fy = y.coerceIn(b.top, b.bottom)
            val maxW = if (hl) ax - b.left else b.right - ax
            val maxH = if (ht) ay - b.top else b.bottom - ay
            var nw = max(abs(fx - ax), abs(fy - ay) * a)
            nw = max(nw, minS)
            nw = min(nw, min(maxW, maxH * a))
            val nh = nw / a
            r.set(
                if (hl) ax - nw else ax, if (ht) ay - nh else ay,
                if (hl) ax else ax + nw, if (ht) ay else ay + nh
            )
        }
        store(r, b)
        changed()
    }
}
