package com.example.tiktrim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** Затемняет область, которая будет обрезана при выбранном формате. */
class CropOverlay @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var videoW = 0
    private var videoH = 0
    var aspect = 0f
        set(v) { field = v; invalidate() }

    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val line = Paint().apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f
    }

    fun setVideo(w: Int, h: Int) { videoW = w; videoH = h; invalidate() }

    override fun onDraw(c: Canvas) {
        if (aspect <= 0f || videoW == 0 || videoH == 0) return
        val s = min(width.toFloat() / videoW, height.toFloat() / videoH)
        val w = videoW * s
        val h = videoH * s
        val l = (width - w) / 2
        val t = (height - h) / 2
        var cw = w
        var ch = w / aspect
        if (ch > h) { ch = h; cw = h * aspect }
        val cl = l + (w - cw) / 2
        val ct = t + (h - ch) / 2
        c.drawRect(l, t, l + w, ct, dim)
        c.drawRect(l, ct + ch, l + w, t + h, dim)
        c.drawRect(l, ct, cl, ct + ch, dim)
        c.drawRect(cl + cw, ct, l + w, ct + ch, dim)
        c.drawRect(cl, ct, cl + cw, ct + ch, line)
    }
}
