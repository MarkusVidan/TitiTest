package com.example.tiktrim

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class SupportActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var msgs: List<Support.Msg> = emptyList()
    private lateinit var list: ListView
    private lateinit var note: TextView
    private lateinit var input: EditText
    private val adapter = object : BaseAdapter() {
        override fun getCount() = msgs.size
        override fun getItem(i: Int) = msgs[i]
        override fun getItemId(i: Int) = msgs[i].id
        override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: LayoutInflater.from(this@SupportActivity).inflate(R.layout.item_msg, parent, false)
            val m = msgs[i]
            val me = m.from == "me"
            val row = v.findViewById<LinearLayout>(R.id.msgRow)
            val bubble = v.findViewById<LinearLayout>(R.id.bubble)
            val text = v.findViewById<TextView>(R.id.msgText)
            val time = v.findViewById<TextView>(R.id.msgTime)
            row.gravity = if (me) Gravity.END else Gravity.START
            bubble.setBackgroundResource(if (me) R.drawable.bg_bubble_me else R.drawable.bg_bubble_dev)
            val fg = if (me) 0xFFFFFFFF.toInt() else com.google.android.material.color.MaterialColors.getColor(
                this@SupportActivity, com.google.android.material.R.attr.colorOnSurface, 0xFFFFFFFF.toInt()
            )
            text.setTextColor(fg)
            time.setTextColor((fg and 0x00FFFFFF) or 0x99000000.toInt())
            text.text = m.text
            time.text = (if (me && !m.sent) "⚠ " else "") +
                DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.ts))
            bubble.alpha = if (me && !m.sent) 0.6f else 1f
            return v
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            exec.execute {
                val n = Support.sync(this@SupportActivity, markUnread = false)
                if (n > 0) ui.post { if (!isDestroyed) reload() }
            }
            ui.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Look.applyAccent(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_support)
        list = findViewById(R.id.msgList)
        note = findViewById(R.id.tvSupportNote)
        input = findViewById(R.id.etMsg)
        list.adapter = adapter
        findViewById<View>(R.id.btnSupportBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSend).setOnClickListener { send() }
        list.setOnItemClickListener { _, _, i, _ ->
            val m = msgs[i]
            if (m.from == "me" && !m.sent) deliver(m)
        }
        reload()
    }

    override fun onResume() {
        super.onResume()
        Support.clearUnread(this)
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        exec.shutdown()
        super.onDestroy()
    }

    private fun reload() {
        msgs = Support.load(this)
        adapter.notifyDataSetChanged()
        if (msgs.isNotEmpty()) list.setSelection(msgs.size - 1)
        note.text = if (!Support.configured()) getString(R.string.support_not_ready) else getString(R.string.support_empty)
        note.visibility = if (msgs.isEmpty() || !Support.configured()) View.VISIBLE else View.GONE
        Support.clearUnread(this)
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (!Support.configured()) { reload(); return }
        input.setText("")
        val m = Support.Msg(System.currentTimeMillis(), "me", text.take(1000), System.currentTimeMillis(), sent = false)
        Support.add(this, m)
        reload()
        deliver(m)
    }

    private fun deliver(m: Support.Msg) {
        exec.execute {
            val ok = Support.send(this, m.text)
            Support.setSent(this, m.id, ok)
            ui.post {
                if (isDestroyed) return@post
                reload()
                if (!ok) Toast.makeText(this, getString(R.string.support_send_fail), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
