package com.example.tiktrim

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.io.ByteArrayOutputStream
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class SupportActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var msgs: List<Support.Msg> = emptyList()
    private lateinit var list: ListView
    private lateinit var note: TextView
    private lateinit var input: EditText
    private val uploading = HashSet<Long>()
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendPhoto(uri)
    }
    private val adapter = object : BaseAdapter() {
        override fun getCount() = msgs.size
        override fun getItem(i: Int) = msgs[i]
        override fun getItemId(i: Int) = msgs[i].id
        override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: LayoutInflater.from(this@SupportActivity).inflate(R.layout.item_msg, parent, false)
            val m = msgs[i]
            val me = m.from == "me"
            val row = v.findViewById<LinearLayout>(R.id.msgRow)
            val bubble = v.findViewById<LinearLayout>(R.id.bubble)
            val text = v.findViewById<TextView>(R.id.msgText)
            val time = v.findViewById<TextView>(R.id.msgTime)
            row.gravity = if (me) Gravity.END else Gravity.START
            bubble.setBackgroundResource(if (me) R.drawable.bg_bubble_me else R.drawable.bg_bubble_dev)
            val fg = if (me) 0xFFFFFFFF.toInt() else com.google.android.material.color.MaterialColors.getColor(
                this@SupportActivity, com.google.android.material.R.attr.colorOnSurface, 0xFFFFFFFF.toInt()
            )
            text.setTextColor(fg)
            time.setTextColor((fg and 0x00FFFFFF) or 0x99000000.toInt())
            text.text = m.text
            time.text = (if (me && !m.sent) "⚠ " else "") +
                DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.ts))
            bubble.alpha = if (me && !m.sent) 0.6f else 1f
            return v
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            exec.execute {
                val n = Support.sync(this@SupportActivity, markUnread = false)
                if (n > 0) ui.post { if (!isDestroyed) reload() }
            }
            ui.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Look.applyAccent(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_support)
        list = findViewById(R.id.msgList)
        note = findViewById(R.id.tvSupportNote)
        input = findViewById(R.id.etMsg)
        list.adapter = adapter
        findViewById<View>(R.id.btnSupportBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSend).setOnClickListener { send() }
        findViewById<View>(R.id.btnAttach).setOnClickListener { showAttachMenu() }
        findViewById<View>(R.id.btnSupportClear).setOnClickListener { confirmClear() }
        list.setOnItemClickListener { _, _, i, _ ->
            val m = msgs[i]
            if (m.from == "me" && !m.sent && m.id !in uploading) deliver(m)
        }
        reload()
    }

    override fun onResume() {
        super.onResume()
        Support.clearUnread(this)
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        exec.shutdown()
        super.onDestroy()
    }

    private fun reload() {
        msgs = Support.load(this)
        adapter.notifyDataSetChanged()
        if (msgs.isNotEmpty()) list.setSelection(msgs.size - 1)
        note.text = if (!Support.configured()) getString(R.string.support_not_ready) else getString(R.string.support_empty)
        note.visibility = if (msgs.isEmpty() || !Support.configured()) View.VISIBLE else View.GONE
        Support.clearUnread(this)
    }

    private fun showAttachMenu() {
        if (!Support.configured()) { reload(); return }
        AlertDialog.Builder(this)
            .setItems(arrayOf(
                getString(R.string.support_menu_photo),
                getString(R.string.support_menu_device),
                getString(R.string.support_menu_logs)
            )) { _, which ->
                when (which) {
                    0 -> pickPhoto.launch("image/*")
                    1 -> confirm(R.string.support_device_confirm) {
                        sendUpload(getString(R.string.support_label_device), "file", "phone_info.txt",
                            "text/plain", Diag.deviceInfo(this).toByteArray(Charsets.UTF_8), "")
                    }
                    2 -> {
                        val log = AppLog.read()
                        if (log.isBlank()) {
                            Toast.makeText(this, R.string.support_logs_empty, Toast.LENGTH_SHORT).show()
                        } else confirm(R.string.support_logs_confirm) {
                            sendUpload(getString(R.string.support_label_logs), "file", "tiktrim_log.txt",
                                "text/plain", log.toByteArray(Charsets.UTF_8), "")
                        }
                    }
                }
            }
            .show()
    }

    private fun confirm(msg: Int, ok: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton(R.string.support_send_btn) { _, _ -> ok() }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage(R.string.support_clear_confirm)
            .setPositiveButton(R.string.support_clear_yes) { _, _ -> Support.clear(this); reload() }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    /** Добавляет сообщение-«вложение» в чат и отправляет файл в фоне. Вызывать из главного потока. */
    private fun sendUpload(label: String, kind: String, name: String, mime: String, data: ByteArray, caption: String) {
        val now = System.currentTimeMillis()
        val m = Support.Msg(now, "me", label, now, sent = false)
        uploading.add(m.id)
        Support.add(this, m)
        reload()
        exec.execute {
            val ok = Support.upload(this, kind, name, mime, data, caption)
            if (ok) Support.setSent(this, m.id, true) else Support.remove(this, m.id)
            ui.post {
                uploading.remove(m.id)
                if (isDestroyed) return@post
                reload()
                if (!ok) Toast.makeText(this, R.string.support_upload_fail, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sendPhoto(uri: Uri) {
        if (!Support.configured()) return
        exec.execute {
            val data = try { compressPhoto(uri) } catch (e: Throwable) { AppLog.error("photo", e); null }
            ui.post {
                if (isDestroyed) return@post
                if (data == null) {
                    Toast.makeText(this, R.string.support_photo_fail, Toast.LENGTH_LONG).show()
                    return@post
                }
                val cap = input.text.toString().trim().take(500)
                input.setText("")
                val label = getString(R.string.support_label_photo) + if (cap.isEmpty()) "" else "\n" + cap
                sendUpload(label, "photo", "photo.jpg", "image/jpeg", data, cap)
            }
        }
    }

    /** Уменьшает фото до 1600 px, учитывает поворот, сжимает в JPEG. */
    private fun compressPhoto(uri: Uri): ByteArray? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
        var bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rot = try {
            contentResolver.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Throwable) { 0f }
        val k = minOf(1f, 1600f / maxOf(bmp.width, bmp.height))
        if (k < 1f || rot != 0f) {
            val mx = Matrix().apply { postScale(k, k); postRotate(rot) }
            val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
            if (out !== bmp) { bmp.recycle(); bmp = out }
        }
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        bmp.recycle()
        return bos.toByteArray()
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (!Support.configured()) { reload(); return }
        input.setText("")
        val m = Support.Msg(System.currentTimeMillis(), "me", text.take(1000), System.currentTimeMillis(), sent = false)
        Support.add(this, m)
        reload()
        deliver(m)
    }

    private fun deliver(m: Support.Msg) {
        exec.execute {
            val ok = Support.send(this, m.text)
            Support.setSent(this, m.id, ok)
            ui.post {
                if (isDestroyed) return@post
                reload()
                if (!ok) Toast.makeText(this, getString(R.string.support_send_fail), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
