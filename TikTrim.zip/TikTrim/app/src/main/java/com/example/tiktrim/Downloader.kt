package com.example.tiktrim

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.net.HttpURLConnection
import java.net.URL

/** Скачивание публичных постов X (Twitter) и Instagram по ссылке. */
object Downloader {

    data class Media(val url: String, val isVideo: Boolean)

    private const val UA_BROWSER =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"
    private const val UA_CRAWLER =
        "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"

    fun extractUrl(text: String): String? =
        Regex("https?://\\S+").find(text)?.value?.trimEnd(')', '.', ',', '"')

    /** Находит прямые ссылки на файлы. Вызывать НЕ из главного потока. */
    fun resolve(input: String): List<Media> {
        val url = extractUrl(input) ?: throw IOException("Не вижу ссылку. Вставь ссылку на пост.")
        val host = Uri.parse(url).host?.lowercase() ?: ""
        return when {
            host.endsWith("x.com") || host.endsWith("twitter.com") ||
                host.endsWith("fxtwitter.com") || host.endsWith("vxtwitter.com") ||
                host.endsWith("fixupx.com") -> twitter(url)
            host.endsWith("instagram.com") -> instagram(url)
            else -> throw IOException("Поддерживаются ссылки X (Twitter) и Instagram.")
        }
    }

    private fun twitter(url: String): List<Media> {
        val m = Regex("/([^/?#]+)/status/(\\d+)").find(url)
            ?: throw IOException("Это не ссылка на конкретный пост.")
        val api = "https://api.fxtwitter.com/${m.groupValues[1]}/status/${m.groupValues[2]}"
        val json = JSONObject(httpText(api, UA_BROWSER))
        val tweet = json.optJSONObject("tweet") ?: json.optJSONObject("status")
            ?: throw IOException("Пост не найден, удалён или закрыт.")
        val media = tweet.optJSONObject("media")
            ?: tweet.optJSONObject("quote")?.optJSONObject("media")
            ?: throw IOException("В посте нет видео или фото.")
        val out = ArrayList<Media>()
        media.optJSONArray("videos")?.let { a ->
            for (i in 0 until a.length()) {
                val u = a.optJSONObject(i)?.optString("url").orEmpty()
                if (u.isNotEmpty()) out.add(Media(u, true))
            }
        }
        if (out.isEmpty()) {
            media.optJSONArray("photos")?.let { a ->
                for (i in 0 until a.length()) {
                    var u = a.optJSONObject(i)?.optString("url").orEmpty()
                    if (u.contains("pbs.twimg.com") && !u.contains("?")) u += "?name=orig"
                    if (u.isNotEmpty()) out.add(Media(u, false))
                }
            }
        }
        if (out.isEmpty()) throw IOException("В посте нет видео или фото.")
        return out
    }

    private fun instagram(url: String): List<Media> {
        val code = Regex("instagram\\.com/(?:[^/?#]+/)?(?:reels?|p|tv)/([A-Za-z0-9_-]+)")
            .find(url)?.groupValues?.get(1)
            ?: throw IOException("Это не ссылка на пост или reel.")

        // 1) Страница встраивания: в ней лежат ссылки на оригиналы (не обрезанное превью)
        try {
            val raw = httpText("https://www.instagram.com/p/$code/embed/captioned/", UA_BROWSER)
            val found = fromEmbed(raw)
            if (found.isNotEmpty()) return found
        } catch (_: IOException) {
            // пробуем запасной способ
        }

        // 2) Запасной способ: og:video (видео там полноразмерное)
        val html = httpText(url.substringBefore('?'), UA_CRAWLER)
        fun meta(prop: String): String? {
            val a = Regex("<meta[^>]+property=\"$prop\"[^>]+content=\"([^\"]+)\"").find(html)
            val b = Regex("<meta[^>]+content=\"([^\"]+)\"[^>]+property=\"$prop\"").find(html)
            return (a ?: b)?.groupValues?.get(1)
                ?.replace("&amp;", "&")?.replace("&#38;", "&")?.replace("&quot;", "\"")
        }
        (meta("og:video") ?: meta("og:video:secure_url"))?.let { return listOf(Media(it, true)) }

        // og:image для постов-картинок обрезан до квадрата, поэтому его НЕ используем
        throw IOException(
            "Не удалось получить файл в оригинальном размере: пост закрыт или нужен вход. " +
                "Это ограничение Instagram, а не ошибка приложения."
        )
    }

    /** Достаёт оригинальные ссылки из страницы встраивания Instagram. */
    private fun fromEmbed(raw: String): List<Media> {
        // JSON на странице экранирован несколько раз — снимаем экранирование
        var t = raw
        repeat(4) { if (t.contains("\\\\")) t = t.replace("\\\\", "\\") }
        t = t.replace("\\/", "/").replace("\\u0026", "&").replace("\\\"", "\"")
            .replace("&amp;", "&")

        fun all(key: String): List<String> =
            Regex("\"$key\"\\s*:\\s*\"(https:[^\"]+)\"").findAll(t)
                .map { it.groupValues[1] }
                .distinctBy { it.substringBefore('?') }
                .toList()

        val videos = all("video_url")
        if (videos.isNotEmpty()) return videos.map { Media(it, true) }

        val images = all("display_url")
        if (images.isNotEmpty()) return images.map { Media(it, false) }

        // Последний шанс: главная картинка на странице встраивания
        Regex("class=\"EmbeddedMediaImage\"[^>]+src=\"([^\"]+)\"").find(raw)?.let {
            return listOf(Media(it.groupValues[1].replace("&amp;", "&"), false))
        }
        return emptyList()
    }

    private fun open(url: String, ua: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return c
    }

    private fun httpText(url: String, ua: String): String {
        val c = open(url, ua)
        try {
            if (c.responseCode >= 400) throw IOException("Сервер ответил ${c.responseCode}. Проверь ссылку.")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает файл в Movies/TikTrim или Pictures/TikTrim. Вызывать НЕ из главного потока. */
    fun download(c: Context, m: Media, onProgress: (Int) -> Unit): Uri {
        val conn = open(m.url, UA_BROWSER)
        try {
            if (conn.responseCode >= 400) throw IOException("Файл не скачался (${conn.responseCode}).")
            val total = conn.contentLengthLong
            val stamp = System.currentTimeMillis()
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, if (m.isVideo) "dl_$stamp.mp4" else "dl_$stamp.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, if (m.isVideo) "video/mp4" else "image/jpeg")
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    if (m.isVideo) "Movies/TikTrim" else "Pictures/TikTrim"
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val coll = if (m.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val out = c.contentResolver.insert(coll, values)
                ?: throw IOException("Не удалось создать файл.")
            try {
                c.contentResolver.openOutputStream(out)!!.use { o ->
                    conn.inputStream.use { i ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var lastPct = -1
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                            }
                        }
                    }
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                c.contentResolver.update(out, values, null, null)
            } catch (e: Exception) {
                try { c.contentResolver.delete(out, null, null) } catch (_: Exception) {}
                throw e
            }
            return out
        } finally {
            conn.disconnect()
        }
    }

    /** Скачивает файл в обычный файл (например, во временную папку). НЕ из главного потока. */
    fun downloadToFile(m: Media, file: File, cancelled: AtomicBoolean, onProgress: (Int) -> Unit) {
        val conn = open(m.url, UA_BROWSER)
        try {
            if (conn.responseCode >= 400) throw IOException("Файл не скачался (${conn.responseCode}).")
            val total = conn.contentLengthLong
            file.parentFile?.mkdirs()
            file.outputStream().use { o ->
                conn.inputStream.use { i ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastPct = -1
                    while (true) {
                        if (cancelled.get()) throw IOException("Отменено")
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            file.delete()
            throw e
        } finally {
            conn.disconnect()
        }
    }
}
