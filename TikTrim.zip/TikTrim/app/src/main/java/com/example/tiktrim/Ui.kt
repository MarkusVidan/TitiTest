package com.example.tiktrim

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import kotlin.math.min

/** Лёгкий «тик» вибро-отклика, как в iOS. */
fun View.tick() {
    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
}

/** Эффект нажатия: кнопка чуть сжимается и пружинит обратно. Клики не перехватывает. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressEffect() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().setStartDelay(0).scaleX(0.95f).scaleY(0.95f)
                    .setDuration(100).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().setStartDelay(0).scaleX(1f).scaleY(1f)
                    .setDuration(260).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
}

/** Блоки страницы по очереди «выплывают» снизу. */
fun staggerIn(container: ViewGroup, baseDelay: Long = 0L) {
    val dy = container.resources.displayMetrics.density * 22f
    for (i in 0 until min(container.childCount, 10)) {
        val c = container.getChildAt(i)
        c.animate().cancel()
        c.alpha = 0f
        c.translationY = dy
        c.animate().setStartDelay(baseDelay + i * 50L).alpha(1f).translationY(0f)
            .setDuration(420).setInterpolator(DecelerateInterpolator(2f))
            .withEndAction { c.animate().setStartDelay(0) }
            .start()
    }
}

/** Число плавно «докручивается» до нового значения. */
fun countUp(tv: TextView, to: Int) {
    val from = tv.text.toString().toIntOrNull() ?: 0
    if (from == to) {
        tv.text = to.toString()
        return
    }
    ValueAnimator.ofInt(from, to).apply {
        duration = 700
        interpolator = DecelerateInterpolator()
        addUpdateListener { tv.text = (it.animatedValue as Int).toString() }
        start()
    }
}
