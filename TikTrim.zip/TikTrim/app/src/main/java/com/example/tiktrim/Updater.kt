package com.example.tiktrim

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Проверка и установка обновлений из GitHub Releases. */
object Updater {

    /** Репозиторий с релизами (должен быть публичным). */
    const val REPO = "MarkusVidan/TitiTest"

    data class Info(val code: Int, val name: String, val url: String, val notes: String)

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            setRequestProperty("User-Agent", "TikTrim")
            setRequestProperty("Accept", "application/vnd.github+json")
        }

    /** Последний релиз или null, если релизов ещё нет. Бросает IOException при сетевой ошибке. */
    @Throws(IOException::class)
    fun fetchLatest(): Info? {
        val c = open("https://api.github.com/repos/$REPO/releases/latest")
        try {
            if (c.responseCode == 404) return null
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val code = j.optString("tag_name").removePrefix("build-").toIntOrNull() ?: return null
            val assets = j.optJSONArray("assets") ?: return null
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    apk = a.optString("browser_download_url")
                    break
                }
            }
            if (apk.isNullOrEmpty()) return null
            val name = j.optString("name").ifBlank { "версия $code" }
            return Info(code, name, apk, j.optString("body"))
        } finally {
            c.disconnect()
        }
    }

    fun currentCode(ctx: Context): Int {
        val p = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        @Suppress("DEPRECATION")
        return if (android.os.Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else p.versionCode
    }

    /** Скачивает APK в кэш приложения. */
    @Throws(IOException::class)
    fun download(ctx: Context, url: String, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "TikTrim-update.apk")
        val c = open(url)
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLength.toLong()
            var done = 0L
            var last = -1
            c.inputStream.use { input ->
                out.outputStream().use { os ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
        } catch (e: IOException) {
            out.delete()
            throw e
        } finally {
            c.disconnect()
        }
        return out
    }

    /** Запускает установку. Если нет разрешения, открывает нужную настройку. */
    fun install(ctx: Context, apk: File) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(
                ctx, "Разреши установку из TikTrim, затем нажми «Обновить» ещё раз",
                Toast.LENGTH_LONG
            ).show()
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
