package com.example.tiktrim

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Небольшой журнал событий и ошибок приложения. Хранится только на телефоне, пока пользователь сам не отправит. */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    fun init(c: Context) {
        file = File(c.filesDir, "app_log.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { log("CRASH", "thread ${t.name}\n" + Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        log("APP", "start")
    }

    @Synchronized
    fun log(tag: String, msg: String) {
        val f = file ?: return
        try {
            if (f.length() > 200_000) f.writeText(f.readText().takeLast(100_000))
            f.appendText("${fmt.format(Date())} [$tag] $msg\n")
        } catch (_: Throwable) {}
    }

    fun error(tag: String, e: Throwable) = log(tag, Log.getStackTraceString(e).take(3000))

    @Synchronized
    fun read(): String = try {
        file?.takeIf { it.exists() }?.readText()?.takeLast(300_000) ?: ""
    } catch (_: Throwable) { "" }
}
