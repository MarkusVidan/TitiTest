package com.example.tiktrim

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat

class WatcherService : Service() {

    private val videos = TikTokFinder.VIDEOS
    private var lastId = 0L

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) = checkNew()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch", "Слежение", NotificationManager.IMPORTANCE_MIN)
        )
        nm.createNotificationChannel(
            NotificationChannel("new", "Новые видео", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = NotificationCompat.Builder(this, "watch")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("TikTrim следит за новыми видео")
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        lastId = maxId()
        contentResolver.registerContentObserver(videos, true, observer)
    }

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(observer)
        super.onDestroy()
    }

    private fun maxId(): Long {
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "_id DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, 1)
        }
        contentResolver.query(videos, arrayOf(MediaStore.Video.Media._ID), args, null)?.use {
            if (it.moveToFirst()) return it.getLong(0)
        }
        return 0L
    }

    private fun checkNew() {
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.RELATIVE_PATH,
            MediaStore.Video.Media.OWNER_PACKAGE_NAME
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "_id > ?")
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf(lastId.toString()))
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "_id ASC")
        }
        val pkgs by lazy { TikTokFinder.apps(this).map { it.pkg.lowercase() }.toSet() }
        contentResolver.query(videos, proj, args, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val path = c.getString(1) ?: ""
                val owner = c.getString(2) ?: ""
                if (id > lastId) lastId = id
                if (TikTokFinder.matches(this, path, owner, pkgs)) notifyNew(id)
            }
        }
    }

    private fun notifyNew(id: Long) {
        val uri = ContentUris.withAppendedId(videos, id)
        val intent = Intent(this, TrimActivity::class.java)
            .putExtra("uri", uri.toString())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            this, id.toInt(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, "new")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("Видео сохранено")
            .setContentText("Нажми, чтобы обрезать")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(id.toInt(), n)
    }
}
