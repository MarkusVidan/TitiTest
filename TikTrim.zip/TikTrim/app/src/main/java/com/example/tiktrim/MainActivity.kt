package com.example.tiktrim

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private enum class Mode { TRIM, SAVE, AUDIO }

    private val pid = "tiktrim-dl"

    private lateinit var pages: List<View>
    private var current = 0
    private lateinit var nav: BottomNavigationView

    // главная
    private lateinit var tvCount: TextView
    private lateinit var tvDlCount: TextView

    // ссылка
    private lateinit var etLink: EditText
    private lateinit var btnFind: Button
    private lateinit var dlStatus: TextView
    private lateinit var dlProgress: LinearProgressIndicator
    private lateinit var btnCancel: Button
    private lateinit var resultCard: View
    private lateinit var ivThumb: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvMeta: TextView
    private lateinit var tvLimit: TextView
    private lateinit var btnTrim: Button
    private lateinit var btnSave: Button
    private lateinit var btnAudio: Button
    private lateinit var doneCard: View
    private lateinit var tvDone: TextView

    // готовые
    private lateinit var videoList: GridView
    private lateinit var videoEmpty: TextView

    // настройки
    private lateinit var tvEngine: TextView

    private var info: Engine.Info? = null
    private var busy = false
    private var cachedFile: File? = null
    private var cachedUrl: String? = null
    private var lastDone: Uri? = null
    private var lastDoneMime = "video/mp4"

    private val exec = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())

    // Кэш превью: не больше 1/8 доступной памяти, лишнее вытесняется само
    private val thumbCache = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).toInt()
    ) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount
    }
    private val loadingThumbs = HashSet<Long>()
    private val animatedItems = HashSet<Int>()

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            startActivity(
                Intent(this, TrimActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    /** Редактор закрылся: если видео сохранено, показываем готовый результат. */
    private val trimLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val u = r.data?.data
        if (r.resultCode == RESULT_OK && u != null) {
            val mime = r.data?.type ?: "video/mp4"
            val audio = mime.startsWith("audio")
            if (!audio) cachedFile = null   // редактор сам удалил временное видео
            showSaved(
                u, mime,
                if (audio) "Готово! Звук в Music/TikTrim"
                else "Готово! Видео в Movies/${Store.folder(this)}"
            )
            countUp(tvCount, Prefs.int(this, "count", 0))
        } else if (cachedFile?.exists() == true) {
            dlStatus.text = "Обрезка не завершена. Видео ещё здесь: нажми «Обрезать» снова."
        }
    }

    private fun homeContainer(): ViewGroup = (pages[0] as ViewGroup).getChildAt(0) as ViewGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pages = listOf(
            findViewById(R.id.pageHome), findViewById(R.id.pageDownload),
            findViewById(R.id.pageVideos), findViewById(R.id.pageSettings), findViewById(R.id.pageAbout)
        )
        val ids = listOf(R.id.nav_home, R.id.nav_download, R.id.nav_videos, R.id.nav_settings, R.id.nav_about)
        nav = findViewById(R.id.nav)
        nav.setOnItemSelectedListener { item ->
            val idx = ids.indexOf(item.itemId)
            if (idx >= 0 && idx != current) {
                nav.tick()
                showPage(idx)
            }
            true
        }

        bindHome()
        bindLink()
        bindVideos()
        bindSettings()
        bindAbout()

        listOf(
            R.id.btnPick, R.id.btnClip, R.id.btnPaste, R.id.btnFind, R.id.btnTrim, R.id.btnSave,
            R.id.btnAudio, R.id.btnRefreshVideos, R.id.btnOpenDone, R.id.btnShareDone,
            R.id.btnUpdateEngine, R.id.btnCancel
        ).forEach { findViewById<View>(it).pressEffect() }

        val ver = packageManager.getPackageInfo(packageName, 0).versionName
        findViewById<TextView>(R.id.versionText).text = "Версия $ver"

        val fromShare = intent?.action == Intent.ACTION_SEND
        handleShare(intent)
        runSplash(skip = savedInstanceState != null || fromShare)
    }

    override fun onResume() {
        super.onResume()
        countUp(tvCount, Prefs.int(this, "count", 0))
        countUp(tvDlCount, Prefs.int(this, "dlcount", 0))
    }

    /** Окно в фокусе: смотрим, не скопировал ли пользователь новую ссылку. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || busy || !Prefs.bool(this, "clip", true)) return
        val u = clipUrl() ?: return
        if (u == Prefs.str(this, "lastclip", "")) return
        Prefs.setStr(this, "lastclip", u)
        openLink(u)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (busy) Engine.cancel(pid)
        exec.shutdown()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    // ---------- Анимации ----------

    /** Заставка при запуске: логотип «выпрыгивает», затем плавно растворяется. */
    private fun runSplash(skip: Boolean) {
        val splash = findViewById<View>(R.id.splash)
        if (skip) {
            splash.visibility = View.GONE
            staggerIn(homeContainer(), 0)
            return
        }
        val d = resources.displayMetrics.density
        val logo = findViewById<View>(R.id.splashLogo)
        val title = findViewById<View>(R.id.splashTitle)
        val sub = findViewById<View>(R.id.splashSub)

        logo.alpha = 0f; logo.scaleX = 0.4f; logo.scaleY = 0.4f; logo.rotation = -14f
        title.alpha = 0f; title.translationY = 24 * d
        sub.alpha = 0f; sub.translationY = 24 * d

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
            .setDuration(680).setInterpolator(OvershootInterpolator(1.9f)).start()
        title.animate().setStartDelay(260).alpha(1f).translationY(0f)
            .setDuration(480).setInterpolator(DecelerateInterpolator(2f)).start()
        sub.animate().setStartDelay(400).alpha(1f).translationY(0f)
            .setDuration(480).setInterpolator(DecelerateInterpolator(2f)).start()

        ui.postDelayed({
            splash.animate().alpha(0f).scaleX(1.08f).scaleY(1.08f)
                .setDuration(380).setInterpolator(AccelerateInterpolator())
                .withEndAction { splash.visibility = View.GONE }.start()
            staggerIn(homeContainer(), 150)
        }, 1300)
    }

    /** Переключение вкладок с мягкой анимацией. */
    private fun showPage(idx: Int) {
        pages.forEachIndexed { i, p ->
            if (i != idx) {
                p.animate().cancel()
                p.visibility = View.GONE
            }
        }
        current = idx
        val p = pages[idx]
        p.animate().cancel()
        p.alpha = 0f
        p.visibility = View.VISIBLE
        p.animate().alpha(1f).setDuration(220).start()
        when {
            p is ViewGroup && p.childCount == 1 && p.getChildAt(0) is ViewGroup ->
                staggerIn(p.getChildAt(0) as ViewGroup, 0)
            p is ViewGroup -> staggerIn(p, 0)
        }
        if (idx == 2) loadVideos()
    }

    // ---------- Инфо ----------
    private fun bindAbout() {
        val logo = findViewById<View>(R.id.aboutLogo)
        logo.cameraDistance = 12000f * resources.displayMetrics.density
        logo.setOnClickListener { v ->
            v.tick()
            v.animate().rotationYBy(360f).scaleX(1.15f).scaleY(1.15f).setDuration(560)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(260).start() }
                .start()
        }
    }

    // ---------- Главная ----------
    private fun bindHome() {
        tvCount = findViewById(R.id.tvCount)
        tvDlCount = findViewById(R.id.tvDlCount)
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickVideo.launch("video/*") }
        findViewById<Button>(R.id.btnClip).setOnClickListener {
            val u = clipUrl()
            if (u == null) {
                Toast.makeText(this, "В буфере нет ссылки. Скопируй ссылку на видео.", Toast.LENGTH_SHORT).show()
                nav.selectedItemId = R.id.nav_download
            } else {
                Prefs.setStr(this, "lastclip", u)
                openLink(u)
            }
        }
    }

    private fun clipUrl(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString() ?: return null
        return Downloader.extractUrl(t)
    }

    /** Ссылка пришла через «Поделиться». */
    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            openLink(t)
        }
    }

    /** Подставляет ссылку и (если включено) сразу ищет видео. */
    private fun openLink(text: String) {
        val u = Downloader.extractUrl(text) ?: text.trim()
        etLink.setText(u)
        nav.selectedItemId = R.id.nav_download
        if (Prefs.bool(this, "autofind", true)) analyze(u)
    }

    // ---------- Ссылка ----------
    private fun bindLink() {
        etLink = findViewById(R.id.etLink)
        btnFind = findViewById(R.id.btnFind)
        dlStatus = findViewById(R.id.dlStatus)
        dlProgress = findViewById(R.id.dlProgress)
        btnCancel = findViewById(R.id.btnCancel)
        resultCard = findViewById(R.id.resultCard)
        ivThumb = findViewById(R.id.ivThumb)
        tvTitle = findViewById(R.id.tvTitle)
        tvMeta = findViewById(R.id.tvMeta)
        tvLimit = findViewById(R.id.tvLimit)
        btnTrim = findViewById(R.id.btnTrim)
        btnSave = findViewById(R.id.btnSave)
        btnAudio = findViewById(R.id.btnAudio)
        doneCard = findViewById(R.id.doneCard)
        tvDone = findViewById(R.id.tvDone)

        findViewById<Button>(R.id.btnPaste).setOnClickListener {
            val u = clipUrl()
            if (u == null) Toast.makeText(this, "В буфере нет ссылки", Toast.LENGTH_SHORT).show()
            else etLink.setText(u)
        }
        btnFind.setOnClickListener { analyze(etLink.text.toString()) }
        btnCancel.setOnClickListener {
            Engine.cancel(pid)
            dlStatus.text = "Отменяю…"
        }
        btnTrim.setOnClickListener { startFetch(Mode.TRIM) }
        btnSave.setOnClickListener { startFetch(Mode.SAVE) }
        btnAudio.setOnClickListener { startFetch(Mode.AUDIO) }
        findViewById<Button>(R.id.btnOpenDone).setOnClickListener {
            lastDone?.let { openFile(it, lastDoneMime) }
        }
        findViewById<Button>(R.id.btnShareDone).setOnClickListener {
            lastDone?.let { shareFile(it, lastDoneMime) }
        }
    }

    private fun setBusy(on: Boolean, text: String, indeterminate: Boolean = true) {
        busy = on
        btnFind.isEnabled = !on
        btnTrim.isEnabled = !on
        btnSave.isEnabled = !on
        btnAudio.isEnabled = !on
        btnCancel.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            // тип индикатора меняем, пока он скрыт
            dlProgress.visibility = View.INVISIBLE
            dlProgress.isIndeterminate = indeterminate
            dlProgress.visibility = View.VISIBLE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            dlProgress.visibility = View.INVISIBLE
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        dlStatus.text = text
    }

    private fun fmtSec(s: Long): String =
        if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)

    /** Шаг 1: узнаём, что за видео и какой длины. Ничего не скачиваем. */
    private fun analyze(link: String) {
        if (busy) return
        if (link.isBlank()) {
            Toast.makeText(this, "Вставь ссылку", Toast.LENGTH_SHORT).show()
            return
        }
        resultCard.visibility = View.GONE
        doneCard.visibility = View.GONE
        info = null
        setBusy(
            true,
            if (Engine.isReady()) "Ищу видео…" else "Готовлю движок. Первый запуск может занять до минуты…"
        )
        exec.execute {
            try {
                val i = Engine.info(this, link.trim())
                ui.post {
                    info = i
                    setBusy(false, "")
                    showResult(i)
                }
                i.thumb?.let { loadThumb(it) }
            } catch (e: Exception) {
                ui.post { setBusy(false, e.message ?: "Не получилось открыть ссылку") }
            }
        }
    }

    private fun showResult(i: Engine.Info) {
        tvTitle.text = i.title.ifBlank { "Видео" }
        tvMeta.text = listOfNotNull(
            i.platform,
            i.uploader.takeIf { it.isNotBlank() },
            if (i.durationSec > 0) fmtSec(i.durationSec) else null
        ).joinToString(" · ")
        ivThumb.setImageDrawable(null)

        val trim = i.canTrim
        btnTrim.visibility = if (trim) View.VISIBLE else View.GONE
        tvLimit.visibility = if (i.hasVideo && !trim) View.VISIBLE else View.GONE
        tvLimit.text = "Видео длиннее 10 минут (${fmtSec(i.durationSec)}). " +
            "Обрезка недоступна, можно только скачать."
        btnSave.text = when {
            !i.hasVideo -> "Сохранить фото"
            trim -> "Скачать как есть"
            else -> "Скачать видео"
        }
        // если обрезки нет, «Скачать» становится главной кнопкой
        btnSave.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (trim) R.color.surface_hi else R.color.ios_blue)
        )
        btnAudio.visibility = if (i.direct == null && i.hasVideo) View.VISIBLE else View.GONE

        resultCard.alpha = 0f
        resultCard.visibility = View.VISIBLE
        resultCard.animate().alpha(1f).setDuration(260).start()
    }

    private fun loadThumb(url: String) {
        val bmp = try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"
            )
            try {
                c.inputStream.use { BitmapFactory.decodeStream(it) }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            null
        }
        if (bmp != null) {
            ui.post {
                if (info?.thumb == url) {
                    ivThumb.alpha = 0f
                    ivThumb.setImageBitmap(bmp)
                    ivThumb.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
    }

    /** Шаг 2: скачиваем. Обрезка: во временную папку, потом в редактор. */
    private fun startFetch(mode: Mode) {
        val i = info ?: return
        if (busy) return
        doneCard.visibility = View.GONE
        val dir = File(cacheDir, "dl")

        if (mode == Mode.TRIM) {
            val cached = cachedFile
            if (cached != null && cached.exists() && cachedUrl == i.url) {
                openEditor(cached)
                return
            }
        }
        dir.listFiles()?.forEach { it.delete() }
        cachedFile = null

        setBusy(true, "Скачиваю…", indeterminate = false)
        dlProgress.setProgressCompat(0, false)
        exec.execute {
            try {
                val onP: (Int) -> Unit = { p ->
                    ui.post {
                        dlProgress.setProgressCompat(p, true)
                        dlStatus.text = if (p >= 100) "Обрабатываю…" else "Скачиваю… $p%"
                    }
                }
                when {
                    !i.hasVideo -> {
                        val list = i.direct ?: emptyList()
                        var last: Uri? = null
                        for ((n, m) in list.withIndex()) {
                            ui.post { dlStatus.text = "Сохраняю ${n + 1} из ${list.size}…" }
                            last = Downloader.download(this, m) { }
                        }
                        val u = last ?: throw java.io.IOException("Нет файлов для сохранения.")
                        Prefs.setInt(this, "dlcount", Prefs.int(this, "dlcount", 0) + 1)
                        ui.post {
                            setBusy(false, "")
                            showSaved(u, "image/jpeg", "Готово! Фото в Pictures/TikTrim")
                        }
                    }
                    mode == Mode.TRIM -> {
                        val f = Engine.fetchVideo(this, i, dir, pid, onP)
                        ui.post {
                            cachedFile = f
                            cachedUrl = i.url
                            setBusy(false, "")
                            openEditor(f)
                        }
                    }
                    mode == Mode.SAVE -> {
                        val f = Engine.fetchVideo(this, i, dir, pid, onP)
                        ui.post { dlStatus.text = "Сохраняю в галерею…" }
                        val u = Store.saveVideo(this, f, Store.safeName(i.title), "Movies/TikTrim")
                        f.delete()
                        Prefs.setInt(this, "dlcount", Prefs.int(this, "dlcount", 0) + 1)
                        ui.post {
                            setBusy(false, "")
                            showSaved(u, "video/mp4", "Готово! Видео в Movies/TikTrim")
                            countUp(tvDlCount, Prefs.int(this, "dlcount", 0))
                        }
                    }
                    else -> {
                        val f = Engine.fetchAudio(this, i, dir, pid, onP)
                        ui.post { dlStatus.text = "Сохраняю в галерею…" }
                        val u = Store.saveAudio(this, f, Store.safeName(i.title))
                        f.delete()
                        ui.post {
                            setBusy(false, "")
                            showSaved(u, "audio/mp4", "Готово! Звук в Music/TikTrim")
                        }
                    }
                }
            } catch (e: Exception) {
                ui.post { setBusy(false, e.message ?: "Не получилось скачать") }
            }
        }
    }

    private fun openEditor(f: File) {
        trimLauncher.launch(
            Intent(this, TrimActivity::class.java)
                .putExtra("uri", Uri.fromFile(f).toString())
                .putExtra("temp", true)
        )
    }

    private fun showSaved(u: Uri, mime: String, text: String) {
        lastDone = u
        lastDoneMime = mime
        dlStatus.text = ""
        tvDone.text = text
        doneCard.alpha = 0f
        doneCard.visibility = View.VISIBLE
        doneCard.animate().alpha(1f).setDuration(260).start()
        doneCard.tick()
    }

    private fun openFile(u: Uri, mime: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "Нет подходящего приложения", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareFile(u: Uri, mime: String) {
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType(mime)
                    .putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                "Поделиться"
            )
        )
    }

    // ---------- Готовые видео ----------
    private fun bindVideos() {
        videoList = findViewById(R.id.videoList)
        videoEmpty = findViewById(R.id.videoEmpty)
        videoList.emptyView = videoEmpty
        findViewById<Button>(R.id.btnRefreshVideos).setOnClickListener { loadVideos() }
    }

    private fun loadVideos() {
        exec.execute {
            val list = try { Store.queryOwn(this) } catch (_: Exception) { emptyList() }
            ui.post {
                animatedItems.clear()
                videoList.adapter = VideoAdapter(list)
                videoList.setOnItemClickListener { v, _, pos, _ ->
                    v.tick()
                    openFile(list[pos].uri, "video/*")
                }
                videoList.setOnItemLongClickListener { _, v, pos, _ ->
                    v.tick()
                    shareFile(list[pos].uri, "video/*")
                    true
                }
            }
        }
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private inner class VideoAdapter(val items: List<Vid>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = items[p].id
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val fresh = cv == null
            val v = cv ?: layoutInflater.inflate(R.layout.item_video, parent, false)
            if (fresh) v.pressEffect()
            val item = items[p]
            val iv = v.findViewById<ImageView>(R.id.thumb)
            v.findViewById<TextView>(R.id.title).text = item.name
            v.findViewById<TextView>(R.id.dur).text = fmtDur(item.durationMs)
            v.findViewById<TextView>(R.id.sub).text = "%.1f МБ".format(item.size / 1048576.0)
            iv.tag = item.id

            // Плавное появление карточек, один раз для каждой
            v.animate().cancel()
            if (animatedItems.add(p)) {
                v.alpha = 0f
                v.translationY = 36f
                v.animate().setStartDelay(((p % 8) * 40).toLong()).alpha(1f).translationY(0f)
                    .setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()
            } else {
                v.alpha = 1f
                v.translationY = 0f
            }

            val cached = thumbCache.get(item.id)
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageDrawable(null)
                if (loadingThumbs.add(item.id)) {
                    exec.execute {
                        val bmp = try {
                            contentResolver.loadThumbnail(item.uri, Size(360, 480), null)
                        } catch (_: Exception) { null }
                        ui.post {
                            loadingThumbs.remove(item.id)
                            if (bmp != null) {
                                thumbCache.put(item.id, bmp)
                                if (iv.tag == item.id) {
                                    iv.alpha = 0f
                                    iv.setImageBitmap(bmp)
                                    iv.animate().alpha(1f).setDuration(220).start()
                                }
                            }
                        }
                    }
                }
            }
            return v
        }
    }

    // ---------- Настройки ----------
    private fun spinner(id: Int, names: List<String>, key: String, def: Int) {
        val sp = findViewById<Spinner>(id)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(Prefs.int(this, key, def).coerceIn(0, names.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, i: Long) {
                Prefs.setInt(this@MainActivity, key, pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun bindSettings() {
        fun sw(id: Int, key: String, def: Boolean) {
            val s = findViewById<MaterialSwitch>(id)
            s.isChecked = Prefs.bool(this, key, def)
            s.setOnCheckedChangeListener { b, v -> b.tick(); Prefs.setBool(this, key, v) }
        }
        sw(R.id.swClip, "clip", true)
        sw(R.id.swAutoFind, "autofind", true)
        sw(R.id.swMute, "mute", false)
        sw(R.id.swShare, "share", false)

        spinner(R.id.spDlq, listOf("До 1080p", "До 720p", "До 480p", "Лучшее"), "dlq", 0)
        spinner(
            R.id.spRatio,
            listOf("Оригинал", "Квадрат 1:1", "9:16", "16:9", "4:5", "Свободно (рамка пальцем)"),
            "ratio", 0
        )

        val folder = findViewById<EditText>(R.id.etFolder)
        folder.setText(Prefs.str(this, "folder", "Trimmed"))
        folder.doAfterTextChanged { Prefs.setStr(this, "folder", it.toString()) }

        tvEngine = findViewById(R.id.tvEngine)
        val btn = findViewById<Button>(R.id.btnUpdateEngine)
        btn.setOnClickListener {
            btn.isEnabled = false
            tvEngine.text = "Обновляю…"
            exec.execute {
                val msg = try {
                    Engine.update(this)
                } catch (e: Exception) {
                    "Не получилось: ${e.message ?: "проверь интернет"}"
                }
                ui.post {
                    btn.isEnabled = true
                    tvEngine.text = msg
                }
            }
        }
    }
}
