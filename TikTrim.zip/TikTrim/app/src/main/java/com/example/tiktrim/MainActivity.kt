package com.example.tiktrim

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.GridView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var pages: List<View>
    private lateinit var switchWatch: MaterialSwitch
    private lateinit var statusText: TextView
    private lateinit var appsText: TextView
    private lateinit var videoList: GridView
    private lateinit var tvCount: TextView
    private lateinit var tvAppsCount: TextView
    private lateinit var videoEmpty: TextView

    private val exec = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val thumbCache = HashMap<Long, Bitmap>()

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasVideoPerm()) {
            setWatching(true)
        } else {
            switchWatch.isChecked = false
            Toast.makeText(this, "Нужно разрешение на видео", Toast.LENGTH_LONG).show()
        }
    }

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            startActivity(
                Intent(this, TrimActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    private fun needed(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasVideoPerm(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pages = listOf(
            findViewById(R.id.pageHome), findViewById(R.id.pageVideos),
            findViewById(R.id.pageSettings), findViewById(R.id.pageAbout)
        )
        val ids = listOf(R.id.nav_home, R.id.nav_videos, R.id.nav_settings, R.id.nav_about)
        findViewById<BottomNavigationView>(R.id.nav).setOnItemSelectedListener { item ->
            val idx = ids.indexOf(item.itemId)
            pages.forEachIndexed { i, p -> p.visibility = if (i == idx) View.VISIBLE else View.GONE }
            if (idx == 1) loadVideos()
            true
        }

        bindHome()
        bindVideos()
        bindSettings()
        val ver = packageManager.getPackageInfo(packageName, 0).versionName
        findViewById<TextView>(R.id.versionText).text = "Версия $ver"
    }

    override fun onResume() {
        super.onResume()
        refreshApps()
        tvCount.text = Prefs.int(this, "count", 0).toString()
    }

    // ---------- Главная ----------
    private fun bindHome() {
        switchWatch = findViewById(R.id.switchWatch)
        statusText = findViewById(R.id.statusText)
        appsText = findViewById(R.id.appsText)
        tvCount = findViewById(R.id.tvCount)
        tvAppsCount = findViewById(R.id.tvAppsCount)
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickVideo.launch("video/*") }
        switchWatch.isChecked = Prefs.bool(this, "enabled", false)
        updateStatus()
        switchWatch.setOnCheckedChangeListener { btn, checked ->
            if (!btn.isPressed) return@setOnCheckedChangeListener
            if (checked) {
                if (hasVideoPerm()) setWatching(true) else permLauncher.launch(needed())
            } else {
                setWatching(false)
            }
        }
        findViewById<Button>(R.id.btnRefreshApps).setOnClickListener { refreshApps() }
    }

    private fun setWatching(on: Boolean) {
        Prefs.setBool(this, "enabled", on)
        switchWatch.isChecked = on
        val i = Intent(this, WatcherService::class.java)
        if (on) ContextCompat.startForegroundService(this, i) else stopService(i)
        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = if (Prefs.bool(this, "enabled", false))
            "Включено: жду новые видео" else "Выключено"
    }

    private fun refreshApps() {
        exec.execute {
            val apps = TikTokFinder.apps(this)
            ui.post {
                tvAppsCount.text = apps.size.toString()
                appsText.text = if (apps.isEmpty())
                    "Не найдено. Добавь слова в Настройках или включи «Следить за ВСЕМИ новыми видео»."
                else apps.joinToString("\n") { "• ${it.label} (${it.pkg})" }
            }
        }
    }

    // ---------- Видео ----------
    private fun bindVideos() {
        videoList = findViewById(R.id.videoList)
        videoEmpty = findViewById(R.id.videoEmpty)
        videoList.emptyView = videoEmpty
        findViewById<Button>(R.id.btnRefreshVideos).setOnClickListener { loadVideos() }
    }

    private fun loadVideos() {
        if (!hasVideoPerm()) {
            videoEmpty.text = "Нет разрешения. Включи слежение на главной вкладке и дай доступ к видео."
            return
        }
        videoEmpty.text = "Ищу видео…"
        exec.execute {
            val list = TikTokFinder.queryVideos(this)
            ui.post {
                videoEmpty.text = "Видео не найдены. Проверь авто-поиск в Настройках."
                videoList.adapter = VideoAdapter(list)
                videoList.setOnItemClickListener { _, _, pos, _ ->
                    startActivity(
                        Intent(this, TrimActivity::class.java)
                            .putExtra("uri", list[pos].uri.toString())
                    )
                }
            }
        }
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private inner class VideoAdapter(val items: List<Vid>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = items[p].id
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_video, parent, false)
            val item = items[p]
            val iv = v.findViewById<ImageView>(R.id.thumb)
            v.findViewById<TextView>(R.id.title).text = item.name
            v.findViewById<TextView>(R.id.dur).text = fmtDur(item.durationMs)
            v.findViewById<TextView>(R.id.sub).text = "%.1f МБ".format(item.size / 1048576.0)
            iv.tag = item.id
            val cached = thumbCache[item.id]
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageDrawable(null)
                exec.execute {
                    val bmp = try {
                        contentResolver.loadThumbnail(item.uri, Size(360, 480), null)
                    } catch (_: Exception) { null }
                    ui.post {
                        if (bmp != null) {
                            thumbCache[item.id] = bmp
                            if (iv.tag == item.id) iv.setImageBitmap(bmp)
                        }
                    }
                }
            }
            return v
        }
    }

    // ---------- Настройки ----------
    private fun bindSettings() {
        fun sw(id: Int, key: String, def: Boolean) {
            val s = findViewById<MaterialSwitch>(id)
            s.isChecked = Prefs.bool(this, key, def)
            s.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v) }
        }
        sw(R.id.swAuto, "auto", true)
        sw(R.id.swAll, "all", false)
        sw(R.id.swDelete, "delete", true)
        sw(R.id.swBoot, "boot", false)
        sw(R.id.swMute, "mute", false)
        sw(R.id.swShare, "share", false)

        val names = listOf("Оригинал", "Квадрат 1:1", "9:16", "16:9", "4:5", "Свободно (рамка пальцем)")
        val sp = findViewById<Spinner>(R.id.spRatio)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(Prefs.int(this, "ratio", 0).coerceIn(0, 5))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Prefs.setInt(this@MainActivity, "ratio", pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val folder = findViewById<EditText>(R.id.etFolder)
        folder.setText(Prefs.str(this, "folder", "Trimmed"))
        folder.doAfterTextChanged { Prefs.setStr(this, "folder", it.toString()) }

        val keys = findViewById<EditText>(R.id.etKeys)
        keys.setText(Prefs.str(this, "keys", ""))
        keys.doAfterTextChanged { Prefs.setStr(this, "keys", it.toString()) }
    }
}
