package com.example.tiktrim

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            ContextCompat.startForegroundService(this, Intent(this, WatcherService::class.java))
            Toast.makeText(this, "Слежение включено", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Нужны все разрешения", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "TikTrim: после сохранения видео из TikTok сразу предлагает его обрезать."
            textSize = 16f
        })
        val all = CheckBox(this).apply {
            text = "Следить за ВСЕМИ новыми видео (если TikTok не определяется)"
            isChecked = prefs.getBoolean("all", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("all", v).apply() }
        }
        root.addView(all)
        root.addView(Button(this).apply {
            text = "Включить"
            setOnClickListener {
                val perms = if (Build.VERSION.SDK_INT >= 33)
                    arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.POST_NOTIFICATIONS)
                else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                permLauncher.launch(perms)
            }
        })
        root.addView(Button(this).apply {
            text = "Выключить"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WatcherService::class.java))
                Toast.makeText(this@MainActivity, "Слежение выключено", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(root)
    }
}
