package com.example.tiktrim

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.util.Locale
import java.util.TimeZone

/** Сведения о телефоне для разработчика. Без личных данных: ни файлов, ни контактов, ни аккаунтов. */
object Diag {
    private fun mb(b: Long) = "${b / (1024 * 1024)} MB"

    fun deviceInfo(c: Context): String {
        val sb = StringBuilder()
        fun line(k: String, v: String) { sb.append(k).append(": ").append(v).append('\n') }
        try {
            val pi = c.packageManager.getPackageInfo(c.packageName, 0)
            line("App", "${pi.versionName} (${pi.longVersionCode})")
            line("Package", c.packageName)
        } catch (_: Throwable) {}
        line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), patch ${Build.VERSION.SECURITY_PATCH}")
        line("Device", "${Build.MANUFACTURER} ${Build.MODEL} (${Build.BRAND} / ${Build.DEVICE})")
        line("Hardware", "${Build.HARDWARE}, ABI ${Build.SUPPORTED_ABIS.joinToString()}")
        try {
            val mi = ActivityManager.MemoryInfo()
            (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            line("RAM", "${mb(mi.availMem)} free of ${mb(mi.totalMem)}${if (mi.lowMemory) " (low memory!)" else ""}")
        } catch (_: Throwable) {}
        try {
            val st = StatFs(c.filesDir.path)
            line("Storage (app)", "${mb(st.availableBytes)} free of ${mb(st.totalBytes)}")
            val ex = StatFs(Environment.getExternalStorageDirectory().path)
            line("Storage (shared)", "${mb(ex.availableBytes)} free of ${mb(ex.totalBytes)}")
        } catch (_: Throwable) {}
        try {
            val dm = c.resources.displayMetrics
            line("Screen", "${dm.widthPixels}x${dm.heightPixels}, ${dm.densityDpi} dpi")
        } catch (_: Throwable) {}
        try {
            val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val chg = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = chg == BatteryManager.BATTERY_STATUS_CHARGING || chg == BatteryManager.BATTERY_STATUS_FULL
                line("Battery", "${if (lvl >= 0) lvl * 100 / scale else -1}%${if (charging) ", charging" else ""}")
            }
        } catch (_: Throwable) {}
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val net = when {
                caps == null -> "none"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                else -> "other"
            }
            line("Network", net + if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) " + VPN" else "")
        } catch (_: Throwable) {}
        line("System language", Locale.getDefault().toLanguageTag())
        line("Time zone", TimeZone.getDefault().id)
        line("App language", Prefs.str(c, "lang", "").ifEmpty { "system" })
        line("App theme", Prefs.int(c, "theme", 0).toString())
        line("Download quality", Prefs.int(c, "dlq", 0).toString())
        line("Download engine ready", Engine.isReady().toString())
        return sb.toString()
    }
}
