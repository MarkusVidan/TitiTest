package com.example.tiktrim

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Чат с разработчиком. Приложение общается с небольшим сервером (support-worker),
 * а сервер пересылает сообщения в Telegram и обратно. Токен бота в приложении НЕ хранится.
 */
object Support {

    /** Адрес сервера-посредника (см. support-worker/README.md). */
    const val BASE_URL = "https://tiktrim-support.zumover08.workers.dev"

    fun configured() = !BASE_URL.contains("YOUR-WORKER") && BASE_URL.startsWith("https://")

    data class Msg(val id: Long, val from: String, val text: String, val ts: Long, val sent: Boolean = true)

    private val lock = Any()

    /** Анонымный номер установки: по нему сервер понимает, кому вернуть ответ. */
    fun uid(c: Context): String {
        val cur = Prefs.str(c, "support_uid", "")
        if (cur.length == 32) return cur
        val n = UUID.randomUUID().toString().replace("-", "")
        Prefs.setStr(c, "support_uid", n)
        return n
    }

    private fun file(c: Context) = File(c.filesDir, "support_chat.json")

    fun load(c: Context): MutableList<Msg> = synchronized(lock) {
        val out = ArrayList<Msg>()
        try {
            val f = file(c)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Msg(o.getLong("id"), o.getString("from"), o.getString("text"), o.getLong("ts"), o.optBoolean("sent", true)))
                }
            }
        } catch (_: Exception) {}
        out
    }

    private fun write(c: Context, list: List<Msg>) {
        val a = JSONArray()
        for (m in list.takeLast(500)) {
            a.put(JSONObject().put("id", m.id).put("from", m.from).put("text", m.text).put("ts", m.ts).put("sent", m.sent))
        }
        file(c).writeText(a.toString())
    }

    fun add(c: Context, m: Msg) = synchronized(lock) {
        val l = load(c); l.add(m); write(c, l)
    }

    fun setSent(c: Context, id: Long, sent: Boolean) = synchronized(lock) {
        val l = load(c)
        val i = l.indexOfFirst { it.id == id }
        if (i >= 0) { l[i] = l[i].copy(sent = sent); write(c, l) }
    }

    fun unread(c: Context): Int = Prefs.int(c, "support_unread", 0)
    fun clearUnread(c: Context) = Prefs.setInt(c, "support_unread", 0)

    fun info(c: Context): String {
        val v = try { c.packageManager.getPackageInfo(c.packageName, 0).versionName } catch (_: Exception) { "?" }
        return "v$v · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL} · " +
            c.resources.configuration.locales[0].language
    }

    private fun call(method: String, path: String, body: JSONObject?): JSONObject {
        val con = URL(BASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
        try {
            con.requestMethod = method
            con.connectTimeout = 10000
            con.readTimeout = 15000
            con.setRequestProperty("User-Agent", "TikTrim")
            if (body != null) {
                con.doOutput = true
                con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = con.responseCode
            val text = (if (code < 400) con.inputStream else con.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code >= 400) throw java.io.IOException("HTTP $code")
            return JSONObject(text)
        } finally {
            con.disconnect()
        }
    }

    /** Стирает историю чата на этом телефоне (уже полученные ответы заново не приходят). */
    fun clear(c: Context) = synchronized(lock) { file(c).delete() }

    fun remove(c: Context, id: Long) = synchronized(lock) {
        val l = load(c)
        if (l.removeAll { it.id == id }) write(c, l)
    }

    /** Отправляет файл (фото, данные телефона, логи). Вызывать НЕ из главного потока. */
    fun upload(c: Context, kind: String, name: String, mime: String, data: ByteArray, caption: String): Boolean {
        if (!configured()) return false
        val boundary = "----tiktrim" + System.currentTimeMillis()
        val body = java.io.ByteArrayOutputStream()
        fun w(s: String) = body.write(s.toByteArray(Charsets.UTF_8))
        fun field(n: String, v: String) {
            w("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n"); w(v); w("\r\n")
        }
        field("uid", uid(c)); field("kind", kind); field("name", name)
        field("info", info(c)); field("caption", caption.take(900))
        w("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\nContent-Type: $mime\r\n\r\n")
        body.write(data)
        w("\r\n--$boundary--\r\n")
        val bytes = body.toByteArray()
        return try {
            val con = URL(BASE_URL.trimEnd('/') + "/upload").openConnection() as HttpURLConnection
            try {
                con.requestMethod = "POST"
                con.connectTimeout = 10000
                con.readTimeout = 45000
                con.doOutput = true
                con.setFixedLengthStreamingMode(bytes.size)
                con.setRequestProperty("User-Agent", "TikTrim")
                con.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                con.outputStream.use { it.write(bytes) }
                val code = con.responseCode
                val text = (if (code < 400) con.inputStream else con.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                if (code >= 400) throw java.io.IOException("HTTP $code")
                JSONObject(text).optBoolean("ok", false)
            } finally { con.disconnect() }
        } catch (e: Exception) { AppLog.error("support-upload", e); false }
    }

    /** Отправляет сообщение разработчику. Вызывать НЕ из главного потока. */
    fun send(c: Context, text: String): Boolean {
        if (!configured()) return false
        return try {
            call("POST", "/send", JSONObject().put("uid", uid(c)).put("text", text).put("info", info(c)))
                .optBoolean("ok", false)
        } catch (e: Exception) { AppLog.error("support", e); false }
    }

    /**
     * Забирает новые ответы разработчика и дописывает их в историю.
     * Возвращает число новых сообщений. Вызывать НЕ из главного потока.
     */
    fun sync(c: Context, markUnread: Boolean): Int {
        if (!configured()) return 0
        return try {
            val after = Prefs.int(c, "support_last", 0)
            val r = call("GET", "/poll?uid=${uid(c)}&after=$after", null)
            val a = r.optJSONArray("msgs") ?: return 0
            var last = after
            var n = 0
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optInt("id", 0)
                if (id <= last) continue
                last = id
                add(c, Msg(System.currentTimeMillis() + i, "dev", o.optString("text"), o.optLong("ts", System.currentTimeMillis())))
                n++
            }
            if (n > 0) {
                Prefs.setInt(c, "support_last", last)
                if (markUnread) Prefs.setInt(c, "support_unread", unread(c) + n)
            }
            n
        } catch (_: Exception) { 0 }
    }
}
