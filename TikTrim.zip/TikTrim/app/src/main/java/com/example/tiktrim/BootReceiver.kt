package com.example.tiktrim

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED &&
            Prefs.bool(c, "enabled", false) && Prefs.bool(c, "boot", false)
        ) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, WatcherService::class.java))
            } catch (_: Exception) {
                // Некоторые версии Android запрещают старт сервиса при загрузке
            }
        }
    }
}
