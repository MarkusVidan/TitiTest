package com.example.tiktrim

import android.app.Application
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.io.File

class TikTrimApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Тема и язык, выбранные в настройках
        AppCompatDelegate.setDefaultNightMode(Look.nightMode(Prefs.int(this, "theme", 0)))
        if (Build.VERSION.SDK_INT < 33) {
            val tag = Prefs.str(this, "lang", "")
            AppCompatDelegate.setApplicationLocales(
                if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                else LocaleListCompat.forLanguageTags(tag)
            )
        }
        // Движок загрузки поднимаем в фоне, чтобы к вставке ссылки он был готов
        Thread { Engine.init(this) }.start()
        // Чистим старые временные файлы
        Thread {
            File(cacheDir, "dl").listFiles()?.forEach {
                if (System.currentTimeMillis() - it.lastModified() > 6 * 3600_000L) it.delete()
            }
        }.start()
    }
}
