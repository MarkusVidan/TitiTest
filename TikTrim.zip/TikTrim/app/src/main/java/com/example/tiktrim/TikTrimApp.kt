package com.example.tiktrim

import android.app.Application
import java.io.File

class TikTrimApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Движок загрузки поднимаем в фоне, чтобы к вставке ссылки он был готов
        Thread { Engine.init(this) }.start()
        // Чистим старые временные файлы
        Thread {
            File(cacheDir, "dl").listFiles()?.forEach {
                if (System.currentTimeMillis() - it.lastModified() > 6 * 3600_000L) it.delete()
            }
        }.start()
    }
}
