package com.example.tiktrim

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class TikApp(val label: String, val pkg: String)
data class Vid(
    val id: Long, val name: String, val durationMs: Long,
    val size: Long, val uri: Uri, val path: String
)

object TikTokFinder {
    private val KEYS = listOf("tiktok", "musically", "ugc.trill", "trill", "ttydyn")
    val VIDEOS: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    fun extraKeys(c: Context): List<String> =
        Prefs.str(c, "keys", "").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    /** Ищет установленные приложения TikTok и его моды по имени пакета и названию. */
    fun apps(c: Context): List<TikApp> {
        val pm = c.packageManager
        val keys = KEYS + extraKeys(c)
        return pm.getInstalledApplications(0)
            .filter { it.packageName != c.packageName }
            .mapNotNull { ai ->
                val label = pm.getApplicationLabel(ai).toString()
                val hay = (ai.packageName + " " + label).lowercase()
                if (keys.any { hay.contains(it) }) TikApp(label, ai.packageName) else null
            }
            .sortedBy { it.label }
    }

    fun matches(c: Context, relPath: String, owner: String, pkgs: Set<String>): Boolean {
        if (owner == c.packageName) return false
        if (Prefs.bool(c, "all", false)) return true
        if (!Prefs.bool(c, "auto", true)) return false
        val p = relPath.lowercase()
        val o = owner.lowercase()
        if (o.isNotEmpty() && o in pkgs) return true
        return (KEYS + extraKeys(c)).any { p.contains(it) || o.contains(it) }
    }

    fun queryVideos(c: Context, limit: Int = 100): List<Vid> {
        val pkgs = apps(c).map { it.pkg.lowercase() }.toSet()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.OWNER_PACKAGE_NAME
        )
        val out = ArrayList<Vid>()
        c.contentResolver.query(
            VIDEOS, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cur ->
            while (cur.moveToNext() && out.size < limit) {
                val path = cur.getString(4) ?: ""
                val owner = cur.getString(5) ?: ""
                if (matches(c, path, owner, pkgs)) {
                    val id = cur.getLong(0)
                    out.add(
                        Vid(id, cur.getString(1) ?: "video", cur.getLong(2), cur.getLong(3),
                            ContentUris.withAppendedId(VIDEOS, id), path)
                    )
                }
            }
        }
        return out
    }
}
