package com.example.tiktrim

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.RangeSlider
import java.io.File
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class TrimActivity : AppCompatActivity() {

    private lateinit var video: VideoView
    private lateinit var slider: RangeSlider
    private lateinit var label: TextView
    private lateinit var cropInfo: TextView
    private lateinit var saveBtn: Button
    private lateinit var delCheck: CheckBox
    private lateinit var shareCheck: CheckBox
    private lateinit var muteSwitch: MaterialSwitch
    private lateinit var chips: ChipGroup
    private lateinit var speedChips: ChipGroup
    private lateinit var overlay: CropOverlay
    private lateinit var progress: LinearProgressIndicator
    private lateinit var src: Uri

    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var transformer: Transformer? = null
    private var exporting = false
    private var savedUri: Uri? = null
    private var videoW = 0
    private var videoH = 0

    // Индексы совпадают с настройкой «Формат по умолчанию»:
    // 0 оригинал, 1 квадрат, 2 9:16, 3 16:9, 4 4:5, 5 свободно
    private val ratios = floatArrayOf(0f, 1f, 9f / 16f, 16f / 9f, 4f / 5f, 0f)
    private val chipIds = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5)
    private var ratioIdx = 0

    private val speeds = floatArrayOf(0.5f, 1f, 1.5f, 2f)
    private val speedIds = intArrayOf(R.id.sp0, R.id.sp1, R.id.sp2, R.id.sp3)
    private var speed = 1f

    // Зацикливает предпросмотр внутри выбранного отрезка
    private val loop = object : Runnable {
        override fun run() {
            val v = slider.values
            if (video.currentPosition >= v[1].toInt()) video.seekTo(v[0].toInt())
            handler.postDelayed(this, 100)
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.setProgressCompat(h.progress, true)
            }
            handler.postDelayed(this, 150)
        }
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            try { contentResolver.delete(src, null, null) } catch (_: Exception) {}
        }
        finishUp()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trim)
        video = findViewById(R.id.video)
        slider = findViewById(R.id.slider)
        label = findViewById(R.id.label)
        cropInfo = findViewById(R.id.cropInfo)
        saveBtn = findViewById(R.id.saveBtn)
        delCheck = findViewById(R.id.delCheck)
        shareCheck = findViewById(R.id.shareCheck)
        muteSwitch = findViewById(R.id.swMute)
        chips = findViewById(R.id.chips)
        speedChips = findViewById(R.id.speedChips)
        overlay = findViewById(R.id.overlay)
        progress = findViewById(R.id.progress)

        val s = intent.data?.toString() ?: intent.getStringExtra("uri")
        if (s == null) { finish(); return }
        src = Uri.parse(s)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        // Удалять оригинал можно только если он в медиатеке
        val canDelete = src.toString().startsWith(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())
        if (canDelete) {
            delCheck.isChecked = Prefs.bool(this, "delete", true)
        } else {
            delCheck.isChecked = false
            delCheck.visibility = View.GONE
        }
        shareCheck.isChecked = Prefs.bool(this, "share", false)
        muteSwitch.isChecked = Prefs.bool(this, "mute", false)

        // Формат кадра
        ratioIdx = Prefs.int(this, "ratio", 0).coerceIn(0, 5)
        chips.check(chipIds[ratioIdx])
        chips.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            ratioIdx = chipIds.indexOf(id).coerceAtLeast(0)
            applyRatio()
        }
        // Если потянули рамку при «Оригинале» — переключаемся на «Свободно»
        overlay.onUserEdit = {
            if (overlay.lockedAspect == 0f && ratioIdx != 5) chips.check(R.id.c5)
        }
        overlay.onChanged = {
            val c = overlay.cropPixels()
            cropInfo.text = if (c[2] > 0) "${c[2]}×${c[3]}" else ""
        }
        overlay.onTap = {
            if (video.isPlaying) video.pause() else video.start()
        }

        // Скорость
        speedChips.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            speed = speeds[speedIds.indexOf(id).coerceAtLeast(0)]
            updateLabel()
        }

        video.setVideoURI(src)
        video.setOnPreparedListener { mp ->
            videoW = mp.videoWidth
            videoH = mp.videoHeight
            overlay.setVideo(videoW, videoH)
            applyRatio()
            val d = video.duration.toFloat()
            slider.valueFrom = 0f
            slider.valueTo = d
            slider.values = listOf(0f, d)
            updateLabel()
            video.start()
            handler.post(loop)
        }
        slider.addOnChangeListener { _, _, fromUser ->
            updateLabel()
            if (fromUser) video.seekTo(slider.values[0].toInt())
        }

        findViewById<View>(R.id.btnSetStart).setOnClickListener {
            val v = slider.values
            val pos = video.currentPosition.toFloat().coerceIn(0f, v[1] - 500f)
            slider.values = listOf(pos, v[1])
            updateLabel()
        }
        findViewById<View>(R.id.btnSetEnd).setOnClickListener {
            val v = slider.values
            val pos = video.currentPosition.toFloat()
                .coerceIn(v[0] + 500f, slider.valueTo)
            slider.values = listOf(v[0], pos)
            updateLabel()
        }

        saveBtn.setOnClickListener { startTrim() }
    }

    private fun applyRatio() {
        when (ratioIdx) {
            0 -> overlay.setFull()
            5 -> overlay.setFree()
            else -> overlay.setAspect(ratios[ratioIdx])
        }
    }

    private fun updateLabel() {
        val v = slider.values
        val len = (v[1] - v[0]) / 1000
        label.text = if (speed == 1f)
            "%.1f – %.1f с  ·  длина %.1f с".format(v[0] / 1000, v[1] / 1000, len)
        else
            "%.1f – %.1f с  ·  итог %.1f с (×%s)".format(
                v[0] / 1000, v[1] / 1000, len / speed,
                if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()
            )
    }

    private fun startTrim() {
        if (exporting) return
        val start = slider.values[0].toLong()
        val end = slider.values[1].toLong()
        if (end - start < 500) {
            Toast.makeText(this, "Отрезок слишком короткий", Toast.LENGTH_SHORT).show()
            return
        }
        video.pause()
        handler.removeCallbacks(loop)
        exporting = true
        saveBtn.isEnabled = false
        saveBtn.alpha = 0.5f
        progress.visibility = View.VISIBLE
        progress.setProgressCompat(0, false)
        label.text = "Обрезаю…"

        val tmp = File(cacheDir, "trim_${System.currentTimeMillis()}.mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start)
            .setEndPositionMs(end)
            .build()
        val item = MediaItem.Builder().setUri(src).setClippingConfiguration(clip).build()

        val mute = muteSwitch.isChecked
        val videoEffects = mutableListOf<Effect>()
        val audioProcs = mutableListOf<AudioProcessor>()

        // Рамка пальцем -> Crop (координаты от -1 до 1, ось Y вверх)
        if (videoW > 0 && videoH > 0 && !overlay.isFull()) {
            val c = overlay.cropPixels()
            val left = c[0] / videoW.toFloat() * 2f - 1f
            val right = (c[0] + c[2]) / videoW.toFloat() * 2f - 1f
            val top = 1f - c[1] / videoH.toFloat() * 2f
            val bottom = 1f - (c[1] + c[3]) / videoH.toFloat() * 2f
            videoEffects.add(Crop(left, right, bottom, top))
        }
        if (speed != 1f) {
            videoEffects.add(SpeedChangeEffect(speed))
            if (!mute) {
                audioProcs.add(SonicAudioProcessor().apply { setSpeed(speed); setPitch(1f) })
            }
        }

        val edited = EditedMediaItem.Builder(item)
            .setRemoveAudio(mute)
            .setEffects(Effects(audioProcs, videoEffects))
            .build()

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poll)
                    progress.setProgressCompat(100, true)
                    label.text = "Сохраняю…"
                    exec.execute { publish(tmp) }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poll)
                    exporting = false
                    progress.visibility = View.INVISIBLE
                    label.text = "Ошибка: ${exportException.message}"
                    saveBtn.isEnabled = true
                    saveBtn.alpha = 1f
                    handler.post(loop)
                }
            })
            .build()
        transformer = t
        t.start(edited, tmp.absolutePath)
        handler.post(poll)
    }

    /** Работает в фоновом потоке: копирует готовый файл в Movies. */
    private fun publish(tmp: File) {
        val folder = Prefs.str(this, "folder", "Trimmed")
            .replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifBlank { "Trimmed" }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "trim_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/$folder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = try {
            contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        } catch (_: Exception) { null }
        if (out == null) {
            runOnUiThread { failSave("Не удалось сохранить") }
            return
        }
        try {
            contentResolver.openOutputStream(out)!!.use { o ->
                tmp.inputStream().use { it.copyTo(o) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(out, values, null, null)
            tmp.delete()
        } catch (e: Exception) {
            runOnUiThread { failSave("Ошибка записи: ${e.message}") }
            return
        }
        runOnUiThread {
            savedUri = out
            Prefs.setInt(this, "count", Prefs.int(this, "count", 0) + 1)
            Toast.makeText(this, "Сохранено в Movies/$folder", Toast.LENGTH_LONG).show()
            if (delCheck.isChecked) askDelete() else finishUp()
        }
    }

    private fun failSave(msg: String) {
        exporting = false
        progress.visibility = View.INVISIBLE
        label.text = msg
        saveBtn.isEnabled = true
        saveBtn.alpha = 1f
    }

    private fun askDelete() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(src))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                contentResolver.delete(src, null, null)
                finishUp()
            }
        } catch (e: RecoverableSecurityException) {
            deleteLauncher.launch(
                IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
            )
        } catch (e: Exception) {
            finishUp()
        }
    }

    /** Последний шаг: при желании открываем «Поделиться», затем закрываемся. */
    private fun finishUp() {
        val u = savedUri
        if (shareCheck.isChecked && u != null) {
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Поделиться видео"))
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        handler.removeCallbacks(poll)
        if (exporting) transformer?.cancel()
        super.onDestroy()
    }
}
