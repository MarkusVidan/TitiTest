package com.example.tiktrim

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.android.material.slider.RangeSlider
import java.io.File

@OptIn(UnstableApi::class)
class TrimActivity : AppCompatActivity() {

    private lateinit var video: VideoView
    private lateinit var slider: RangeSlider
    private lateinit var label: TextView
    private lateinit var saveBtn: Button
    private lateinit var delCheck: CheckBox
    private lateinit var src: Uri
    private val handler = Handler(Looper.getMainLooper())

    // Зацикливает предпросмотр внутри выбранного отрезка
    private val loop = object : Runnable {
        override fun run() {
            val v = slider.values
            if (video.currentPosition >= v[1].toInt()) video.seekTo(v[0].toInt())
            handler.postDelayed(this, 100)
        }
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            try { contentResolver.delete(src, null, null) } catch (_: Exception) {}
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trim)
        video = findViewById(R.id.video)
        slider = findViewById(R.id.slider)
        label = findViewById(R.id.label)
        saveBtn = findViewById(R.id.saveBtn)
        delCheck = findViewById(R.id.delCheck)

        val s = intent.getStringExtra("uri")
        if (s == null) { finish(); return }
        src = Uri.parse(s)

        video.setVideoURI(src)
        video.setOnPreparedListener {
            val d = video.duration.toFloat()
            slider.valueFrom = 0f
            slider.valueTo = d
            slider.values = listOf(0f, d)
            updateLabel()
            video.start()
            handler.post(loop)
        }
        slider.addOnChangeListener { _, _, fromUser ->
            updateLabel()
            if (fromUser) video.seekTo(slider.values[0].toInt())
        }
        saveBtn.setOnClickListener { startTrim() }
    }

    private fun updateLabel() {
        val v = slider.values
        label.text = "%.1f – %.1f сек (длина %.1f)".format(v[0] / 1000, v[1] / 1000, (v[1] - v[0]) / 1000)
    }

    private fun startTrim() {
        val start = slider.values[0].toLong()
        val end = slider.values[1].toLong()
        if (end - start < 500) {
            Toast.makeText(this, "Отрезок слишком короткий", Toast.LENGTH_SHORT).show()
            return
        }
        video.pause()
        handler.removeCallbacks(loop)
        saveBtn.isEnabled = false
        label.text = "Обрезаю…"

        val tmp = File(cacheDir, "trim.mp4")
        tmp.delete()
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start)
            .setEndPositionMs(end)
            .build()
        val item = MediaItem.Builder().setUri(src).setClippingConfiguration(clip).build()

        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    publish(tmp)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    label.text = "Ошибка: ${exportException.message}"
                    saveBtn.isEnabled = true
                }
            })
            .build()
        transformer.start(EditedMediaItem.Builder(item).build(), tmp.absolutePath)
    }

    private fun publish(tmp: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "trim_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Trimmed")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        if (out == null) {
            label.text = "Не удалось сохранить"
            saveBtn.isEnabled = true
            return
        }
        contentResolver.openOutputStream(out)!!.use { o ->
            tmp.inputStream().use { it.copyTo(o) }
        }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        contentResolver.update(out, values, null, null)
        tmp.delete()
        Toast.makeText(this, "Сохранено в Movies/Trimmed", Toast.LENGTH_LONG).show()

        if (delCheck.isChecked) askDelete() else finish()
    }

    private fun askDelete() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(src))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                contentResolver.delete(src, null, null)
                finish()
            }
        } catch (e: RecoverableSecurityException) {
            deleteLauncher.launch(
                IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
            )
        } catch (e: Exception) {
            finish()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
