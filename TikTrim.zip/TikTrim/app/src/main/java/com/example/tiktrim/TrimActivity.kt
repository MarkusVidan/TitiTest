package com.example.tiktrim

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.RangeSlider
import java.io.File
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class TrimActivity : AppCompatActivity() {

    private lateinit var video: VideoView
    private lateinit var slider: RangeSlider
    private lateinit var label: TextView
    private lateinit var tvPos: TextView
    private lateinit var cropInfo: TextView
    private lateinit var saveBtn: Button
    private lateinit var btnAudio: Button
    private lateinit var btnFrame: Button
    private lateinit var delCheck: CheckBox
    private lateinit var shareCheck: CheckBox
    private lateinit var muteSwitch: MaterialSwitch
    private lateinit var chips: ChipGroup
    private lateinit var speedChips: ChipGroup
    private lateinit var overlay: CropOverlay
    private lateinit var progress: LinearProgressIndicator
    private lateinit var doneOverlay: View
    private lateinit var doneCircle: View
    private lateinit var doneText: TextView
    private lateinit var src: Uri

    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var transformer: Transformer? = null
    private var exporting = false
    private var exportAudio = false
    private var savedUri: Uri? = null
    private var savedMime = "video/mp4"
    private var videoW = 0
    private var videoH = 0
    private var canDelete = false

    // Индексы совпадают с настройкой «Формат по умолчанию»:
    // 0 оригинал, 1 квадрат, 2 9:16, 3 16:9, 4 4:5, 5 свободно
    private val ratios = floatArrayOf(0f, 1f, 9f / 16f, 16f / 9f, 4f / 5f, 0f)
    private val chipIds = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5)
    private var ratioIdx = 0

    private val speeds = floatArrayOf(0.5f, 1f, 1.5f, 2f)
    private val speedIds = intArrayOf(R.id.sp0, R.id.sp1, R.id.sp2, R.id.sp3)
    private var speed = 1f

    // Зацикливает предпросмотр внутри отрезка и обновляет время
    private val loop = object : Runnable {
        override fun run() {
            val v = slider.values
            val pos = video.currentPosition
            if (video.isPlaying && pos >= v[1].toInt()) video.seekTo(v[0].toInt())
            tvPos.text = fmt(pos)
            handler.postDelayed(this, 100)
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.setProgressCompat(h.progress, true)
            }
            handler.postDelayed(this, 150)
        }
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            try { contentResolver.delete(src, null, null) } catch (_: Exception) {}
        }
        finishUp()
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(R.anim.ios_in, R.anim.ios_hold)
        setContentView(R.layout.activity_trim)
        video = findViewById(R.id.video)
        slider = findViewById(R.id.slider)
        label = findViewById(R.id.label)
        tvPos = findViewById(R.id.tvPos)
        cropInfo = findViewById(R.id.cropInfo)
        saveBtn = findViewById(R.id.saveBtn)
        btnAudio = findViewById(R.id.btnAudio)
        btnFrame = findViewById(R.id.btnFrame)
        delCheck = findViewById(R.id.delCheck)
        shareCheck = findViewById(R.id.shareCheck)
        muteSwitch = findViewById(R.id.swMute)
        chips = findViewById(R.id.chips)
        speedChips = findViewById(R.id.speedChips)
        overlay = findViewById(R.id.overlay)
        progress = findViewById(R.id.progress)
        doneOverlay = findViewById(R.id.doneOverlay)
        doneCircle = findViewById(R.id.doneCircle)
        doneText = findViewById(R.id.doneText)

        val s = intent.data?.toString() ?: intent.getStringExtra("uri")
        if (s == null) { finish(); return }
        src = Uri.parse(s)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        listOf(
            R.id.saveBtn, R.id.btnAudio, R.id.btnFrame, R.id.btnSetStart,
            R.id.btnSetEnd, R.id.btnMinus, R.id.btnPlus, R.id.btnBack
        ).forEach { findViewById<View>(it).pressEffect() }

        // Удалять оригинал можно только если он в медиатеке
        canDelete = src.toString().startsWith(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())
        if (canDelete) {
            delCheck.isChecked = Prefs.bool(this, "delete", true)
        } else {
            delCheck.isChecked = false
            delCheck.visibility = View.GONE
        }
        shareCheck.isChecked = Prefs.bool(this, "share", false)
        muteSwitch.isChecked = Prefs.bool(this, "mute", false)

        // Формат кадра
        ratioIdx = Prefs.int(this, "ratio", 0).coerceIn(0, 5)
        chips.check(chipIds[ratioIdx])
        chips.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            ratioIdx = chipIds.indexOf(id).coerceAtLeast(0)
            chips.tick()
            applyRatio()
        }
        // Если потянули рамку при «Оригинале» — переключаемся на «Свободно»
        overlay.onUserEdit = {
            if (overlay.lockedAspect == 0f && ratioIdx != 5) chips.check(R.id.c5)
        }
        overlay.onChanged = {
            val c = overlay.cropPixels()
            cropInfo.text = if (c[2] > 0) "${c[2]}×${c[3]}" else ""
        }
        overlay.onTap = {
            if (video.isPlaying) video.pause() else video.start()
        }

        // Скорость
        speedChips.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            speed = speeds[speedIds.indexOf(id).coerceAtLeast(0)]
            speedChips.tick()
            updateLabel()
        }

        video.setVideoURI(src)
        video.setOnPreparedListener { mp ->
            videoW = mp.videoWidth
            videoH = mp.videoHeight
            overlay.setVideo(videoW, videoH)
            applyRatio()
            val d = video.duration.toFloat()
            slider.valueFrom = 0f
            slider.valueTo = d
            slider.values = listOf(0f, d)
            updateLabel()
            video.start()
            handler.post(loop)
        }
        slider.addOnChangeListener { _, _, fromUser ->
            updateLabel()
            if (fromUser) video.seekTo(slider.values[0].toInt())
        }

        findViewById<View>(R.id.btnSetStart).setOnClickListener {
            val v = slider.values
            val pos = video.currentPosition.toFloat().coerceIn(0f, v[1] - 500f)
            slider.values = listOf(pos, v[1])
            it.tick()
            updateLabel()
        }
        findViewById<View>(R.id.btnSetEnd).setOnClickListener {
            val v = slider.values
            val pos = video.currentPosition.toFloat().coerceIn(v[0] + 500f, slider.valueTo)
            slider.values = listOf(v[0], pos)
            it.tick()
            updateLabel()
        }
        // Точная перемотка на секунду
        findViewById<View>(R.id.btnMinus).setOnClickListener { step(-1000); it.tick() }
        findViewById<View>(R.id.btnPlus).setOnClickListener { step(1000); it.tick() }

        saveBtn.setOnClickListener { startTrim(false) }
        btnAudio.setOnClickListener { startTrim(true) }
        btnFrame.setOnClickListener { saveFrame() }
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.ios_hold, R.anim.ios_out)
    }

    private fun fmt(ms: Int): String {
        val t = (ms / 100).coerceAtLeast(0)
        return "%d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
    }

    private fun step(deltaMs: Int) {
        if (video.duration <= 0) return
        video.pause()
        val p = (video.currentPosition + deltaMs).coerceIn(0, video.duration)
        video.seekTo(p)
        tvPos.text = fmt(p)
    }

    private fun applyRatio() {
        when (ratioIdx) {
            0 -> overlay.setFull()
            5 -> overlay.setFree()
            else -> overlay.setAspect(ratios[ratioIdx])
        }
    }

    private fun updateLabel() {
        val v = slider.values
        val len = (v[1] - v[0]) / 1000
        label.text = if (speed == 1f)
            "%.1f – %.1f с  ·  длина %.1f с".format(v[0] / 1000, v[1] / 1000, len)
        else
            "%.1f – %.1f с  ·  итог %.1f с (×%s)".format(
                v[0] / 1000, v[1] / 1000, len / speed,
                if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()
            )
    }

    // ---------- Обрезка и экспорт звука ----------

    private fun startTrim(audioOnly: Boolean) {
        if (exporting) return
        val start = slider.values[0].toLong()
        val end = slider.values[1].toLong()
        if (end - start < 500) {
            Toast.makeText(this, "Отрезок слишком короткий", Toast.LENGTH_SHORT).show()
            return
        }
        video.pause()
        handler.removeCallbacks(loop)
        exporting = true
        exportAudio = audioOnly
        setBusy(true)
        label.text = if (audioOnly) "Вытаскиваю звук…" else "Обрезаю…"

        val tmp = File(cacheDir, "trim_${System.currentTimeMillis()}." + if (audioOnly) "m4a" else "mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start)
            .setEndPositionMs(end)
            .build()
        val item = MediaItem.Builder().setUri(src).setClippingConfiguration(clip).build()

        val mute = muteSwitch.isChecked && !audioOnly
        val videoEffects = mutableListOf<Effect>()
        val audioProcs = mutableListOf<AudioProcessor>()

        if (!audioOnly) {
            // Рамка пальцем -> Crop (координаты от -1 до 1, ось Y вверх)
            if (videoW > 0 && videoH > 0 && !overlay.isFull()) {
                val c = overlay.cropPixels()
                val left = c[0] / videoW.toFloat() * 2f - 1f
                val right = (c[0] + c[2]) / videoW.toFloat() * 2f - 1f
                val top = 1f - c[1] / videoH.toFloat() * 2f
                val bottom = 1f - (c[1] + c[3]) / videoH.toFloat() * 2f
                videoEffects.add(Crop(left, right, bottom, top))
            }
            if (speed != 1f) videoEffects.add(SpeedChangeEffect(speed))
        }
        if (speed != 1f && !mute) {
            audioProcs.add(SonicAudioProcessor().apply { setSpeed(speed); setPitch(1f) })
        }

        val builder = EditedMediaItem.Builder(item)
            .setRemoveAudio(mute)
            .setEffects(Effects(audioProcs, videoEffects))
        if (audioOnly) builder.setRemoveVideo(true)
        val edited = builder.build()

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poll)
                    progress.setProgressCompat(100, true)
                    label.text = "Сохраняю…"
                    exec.execute { publish(tmp, audioOnly) }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poll)
                    failSave("Ошибка: ${exportException.message}")
                    handler.post(loop)
                }
            })
            .build()
        transformer = t
        t.start(edited, tmp.absolutePath)
        handler.post(poll)
    }

    private fun setBusy(busy: Boolean) {
        saveBtn.isEnabled = !busy
        btnAudio.isEnabled = !busy
        val a = if (busy) 0.5f else 1f
        saveBtn.alpha = a
        btnAudio.alpha = a
        if (busy) {
            progress.visibility = View.VISIBLE
            progress.setProgressCompat(0, false)
        } else {
            progress.visibility = View.INVISIBLE
        }
    }

    /** Фоновый поток: копирует готовый файл в медиатеку. */
    private fun publish(tmp: File, audioOnly: Boolean) {
        val folder = Prefs.str(this, "folder", "Trimmed")
            .replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifBlank { "Trimmed" }
        val stamp = System.currentTimeMillis()
        val values = ContentValues()
        val collection: Uri
        val where: String
        if (audioOnly) {
            collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            where = "Music/TikTrim"
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "audio_$stamp.m4a")
            values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
        } else {
            collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            where = "Movies/$folder"
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "trim_$stamp.mp4")
            values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        }
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, where)
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)

        val out = try { contentResolver.insert(collection, values) } catch (_: Exception) { null }
        if (out == null) {
            runOnUiThread { failSave("Не удалось сохранить") }
            return
        }
        try {
            contentResolver.openOutputStream(out)!!.use { o ->
                tmp.inputStream().use { it.copyTo(o) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(out, values, null, null)
            tmp.delete()
        } catch (e: Exception) {
            try { contentResolver.delete(out, null, null) } catch (_: Exception) {}
            runOnUiThread { failSave("Ошибка записи: ${e.message}") }
            return
        }
        runOnUiThread {
            savedUri = out
            savedMime = if (audioOnly) "audio/mp4" else "video/mp4"
            if (!audioOnly) Prefs.setInt(this, "count", Prefs.int(this, "count", 0) + 1)
            Toast.makeText(this, "Сохранено в $where", Toast.LENGTH_LONG).show()
            showDone(if (audioOnly) "Звук сохранён" else "Готово") {
                if (!audioOnly && canDelete && delCheck.isChecked) askDelete() else finishUp()
            }
        }
    }

    private fun failSave(msg: String) {
        exporting = false
        setBusy(false)
        label.text = msg
    }

    /** Зелёная галочка в стиле iOS, затем следующий шаг. */
    private fun showDone(text: String, next: () -> Unit) {
        doneText.text = text
        doneOverlay.alpha = 0f
        doneOverlay.visibility = View.VISIBLE
        doneOverlay.animate().alpha(1f).setDuration(180).start()
        doneCircle.scaleX = 0.2f
        doneCircle.scaleY = 0.2f
        doneCircle.animate().scaleX(1f).scaleY(1f).setDuration(520)
            .setInterpolator(OvershootInterpolator(2.6f)).start()
        doneCircle.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.LONG_PRESS
        )
        handler.postDelayed({ if (!isFinishing) next() }, 950)
    }

    // ---------- Сохранить кадр как фото ----------

    private fun saveFrame() {
        if (videoW <= 0) return
        val posUs = video.currentPosition.toLong() * 1000
        // «вспышка» на превью
        video.animate().alpha(0.25f).setDuration(70).withEndAction {
            video.animate().alpha(1f).setDuration(220).start()
        }.start()
        btnFrame.tick()
        btnFrame.isEnabled = false
        exec.execute {
            var msg = ""
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, src)
                var bmp: Bitmap = r.getFrameAtTime(posUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("не удалось достать кадр")
                if (!overlay.isFull()) {
                    val c = overlay.cropPixels()
                    val sx = bmp.width / videoW.toFloat()
                    val sy = bmp.height / videoH.toFloat()
                    val x = (c[0] * sx).toInt().coerceIn(0, bmp.width - 1)
                    val y = (c[1] * sy).toInt().coerceIn(0, bmp.height - 1)
                    val w = (c[2] * sx).toInt().coerceIn(1, bmp.width - x)
                    val h = (c[3] * sy).toInt().coerceIn(1, bmp.height - y)
                    bmp = Bitmap.createBitmap(bmp, x, y, w, h)
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "frame_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/TikTrim")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val out = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("не удалось создать файл")
                try {
                    contentResolver.openOutputStream(out)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(out, values, null, null)
                } catch (e: Exception) {
                    try { contentResolver.delete(out, null, null) } catch (_: Exception) {}
                    throw e
                }
                msg = "Кадр сохранён в Pictures/TikTrim"
            } catch (e: Exception) {
                msg = "Не удалось сохранить кадр: ${e.message}"
            } finally {
                r.release()
            }
            runOnUiThread {
                btnFrame.isEnabled = true
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Завершение ----------

    private fun askDelete() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(src))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                contentResolver.delete(src, null, null)
                finishUp()
            }
        } catch (e: RecoverableSecurityException) {
            deleteLauncher.launch(
                IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
            )
        } catch (e: Exception) {
            finishUp()
        }
    }

    /** Последний шаг: при желании открываем «Поделиться», затем закрываемся. */
    private fun finishUp() {
        val u = savedUri
        if (shareCheck.isChecked && u != null) {
            val send = Intent(Intent.ACTION_SEND)
                .setType(savedMime)
                .putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Поделиться"))
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (exporting) transformer?.cancel()
        exec.shutdown()
        super.onDestroy()
    }
}
