package com.example.tiktrim

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Всё, что связано с загрузкой по ссылке. Основа: yt-dlp (сотни сервисов).
 * Если yt-dlp не справился с X или Instagram, пробуем лёгкий запасной путь (Downloader).
 */
object Engine {

    /** Дольше этого видео только скачиваем, обрезку не предлагаем. */
    const val TRIM_LIMIT_SEC = 600L

    data class Info(
        val url: String,
        val title: String,
        val uploader: String,
        val durationSec: Long,           // 0 = неизвестно
        val thumb: String?,
        val platform: String,
        val direct: List<Downloader.Media>? = null   // запасной путь
    ) {
        val hasVideo: Boolean get() = direct == null || direct.any { it.isVideo }
        val canTrim: Boolean get() = hasVideo && durationSec <= TRIM_LIMIT_SEC
    }

    @Volatile private var ready = false
    @Volatile private var initError: String? = null
    private val cancelled = AtomicBoolean(false)

    fun isReady() = ready

    @Synchronized
    fun init(c: Context) {
        if (ready) return
        try {
            YoutubeDL.getInstance().init(c.applicationContext)
            FFmpeg.getInstance().init(c.applicationContext)
            ready = true
            initError = null
        } catch (t: Throwable) {
            initError = t.message ?: t.javaClass.simpleName
        }
    }

    private fun need(c: Context) {
        init(c)
        if (!ready) throw IOException("Движок загрузки не запустился: ${initError ?: "неизвестная ошибка"}")
    }

    // ---------- Анализ ссылки ----------

    /** Узнаёт название, длительность и обложку. Вызывать НЕ из главного потока. */
    fun info(c: Context, link: String): Info {
        val url = Downloader.extractUrl(link)
            ?: throw IOException("Не вижу ссылку. Вставь ссылку на видео.")
        val host = Uri.parse(url).host?.lowercase() ?: ""
        try {
            need(c)
            val req = YoutubeDLRequest(url)
            req.addOption("--dump-single-json")
            req.addOption("--no-playlist")
            req.addOption("--playlist-items", "1")
            req.addOption("--no-warnings")
            req.addOption("--socket-timeout", "20")
            val out = YoutubeDL.getInstance().execute(req).out ?: ""
            val s = out.indexOf('{')
            val e = out.lastIndexOf('}')
            if (s < 0 || e <= s) throw IOException("Сервис не вернул данные о видео.")
            var json = JSONObject(out.substring(s, e + 1))
            if (json.optString("_type") == "playlist") {
                json = json.optJSONArray("entries")?.optJSONObject(0)
                    ?: throw IOException("В ссылке нет видео.")
            }
            if (json.optBoolean("is_live")) {
                throw IOException("Это прямой эфир, его скачать нельзя.")
            }
            return Info(
                url = url,
                title = json.optString("title").ifBlank { json.optString("fulltitle") },
                uploader = json.optString("uploader").ifBlank { json.optString("channel") },
                durationSec = json.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
                thumb = json.optString("thumbnail").takeIf { it.startsWith("http") },
                platform = platformName(json.optString("extractor_key"), host)
            )
        } catch (ex: Exception) {
            // запасной путь только для X и Instagram
            if (isLightHost(host)) {
                try { return lightInfo(url, host) } catch (_: Exception) {}
            }
            throw IOException(friendly(ex))
        }
    }

    private fun isLightHost(h: String) =
        h.endsWith("x.com") || h.endsWith("twitter.com") || h.endsWith("instagram.com") ||
            h.endsWith("fxtwitter.com") || h.endsWith("vxtwitter.com") || h.endsWith("fixupx.com")

    private fun lightInfo(url: String, host: String): Info {
        val list = Downloader.resolve(url)
        val firstVideo = list.firstOrNull { it.isVideo }
        var dur = 0L
        if (firstVideo != null) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(firstVideo.url, HashMap<String, String>())
                dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L) / 1000
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
        val plat = if (host.contains("instagram")) "Instagram" else "X (Twitter)"
        val title = when {
            firstVideo != null -> "Видео из $plat"
            list.size > 1 -> "Фото из $plat (${list.size})"
            else -> "Фото из $plat"
        }
        return Info(url, title, "", dur, null, plat, list)
    }

    private fun platformName(key: String, host: String): String {
        val k = key.lowercase()
        return when {
            k.contains("tiktok") -> "TikTok"
            k.contains("youtube") -> "YouTube"
            k.contains("instagram") -> "Instagram"
            k.contains("twitter") -> "X (Twitter)"
            k.contains("facebook") -> "Facebook"
            k.contains("reddit") -> "Reddit"
            k.contains("vimeo") -> "Vimeo"
            k.contains("twitch") -> "Twitch"
            k.contains("pinterest") -> "Pinterest"
            k.contains("snapchat") -> "Snapchat"
            k.contains("bilibili") -> "Bilibili"
            k.contains("dailymotion") -> "Dailymotion"
            k.contains("soundcloud") -> "SoundCloud"
            k == "vk" || k.startsWith("vk") -> "VK"
            k.contains("likee") -> "Likee"
            k.contains("rutube") -> "Rutube"
            key.isNotBlank() -> key
            else -> host.removePrefix("www.")
        }
    }

    private fun friendly(e: Exception): String {
        val m = e.message ?: return "Не получилось открыть ссылку."
        if (e is IOException && !m.contains("ERROR", ignoreCase = true) && m.length < 160) return m
        return when {
            m.contains("Unsupported URL", true) -> "Эта ссылка не поддерживается."
            m.contains("private", true) || m.contains("login", true) ||
                m.contains("sign in", true) || m.contains("log in", true) ->
                "Видео закрытое или нужен вход в аккаунт."
            m.contains("429") -> "Сервис просит подождать. Попробуй позже."
            m.contains("not available", true) || m.contains("unavailable", true) ->
                "Видео недоступно (удалено или закрыто)."
            m.contains("geo", true) -> "Видео недоступно в твоём регионе."
            m.contains("Unable to download", true) || m.contains("urlopen", true) ||
                m.contains("resolve", true) -> "Нет связи с сервисом. Проверь интернет."
            else -> m.lineSequence().firstOrNull { it.contains("ERROR") }
                ?.replace("ERROR:", "")?.trim()?.take(160)
                ?: m.lineSequence().first().take(160)
        }
    }

    // ---------- Скачивание во временную папку ----------

    private fun formatFor(c: Context): String {
        val h = when (Prefs.int(c, "dlq", 0)) { 0 -> 1080; 1 -> 720; 2 -> 480; else -> 4320 }
        return "bv*[vcodec^=avc1][height<=$h]+ba[ext=m4a]/b[ext=mp4][height<=$h]/" +
            "b[height<=$h]/bv*[height<=$h]+ba/b"
    }

    private fun pick(dir: File, stamp: Long): File =
        dir.listFiles()
            ?.filter { it.name.startsWith("dl_$stamp.") && !it.name.endsWith(".part") &&
                !it.name.endsWith(".ytdl") && !it.name.endsWith(".temp") }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("Файл не скачался.")

    /** Видео во временную папку (в галерею оно НЕ попадает). */
    fun fetchVideo(
        c: Context, info: Info, dir: File, processId: String, onProgress: (Int) -> Unit
    ): File {
        dir.mkdirs()
        cancelled.set(false)
        val stamp = System.currentTimeMillis()
        val direct = info.direct
        if (direct != null) {
            val m = direct.firstOrNull { it.isVideo } ?: throw IOException("В посте нет видео.")
            val f = File(dir, "dl_$stamp.mp4")
            Downloader.downloadToFile(m, f, cancelled, onProgress)
            return f
        }
        need(c)
        val req = YoutubeDLRequest(info.url)
        req.addOption("--no-playlist")
        req.addOption("--playlist-items", "1")
        req.addOption("--no-mtime")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "20")
        req.addOption("--retries", "3")
        req.addOption("-f", formatFor(c))
        req.addOption("--merge-output-format", "mp4")
        req.addOption("-o", File(dir, "dl_$stamp.%(ext)s").absolutePath)
        try {
            YoutubeDL.getInstance().execute(req, processId) { p, _, _ ->
                onProgress(p.toInt().coerceIn(0, 100))
            }
        } catch (e: Exception) {
            if (cancelled.get()) throw IOException("Отменено")
            throw IOException(friendly(e))
        }
        return pick(dir, stamp)
    }

    /** Только звук (m4a) во временную папку. */
    fun fetchAudio(
        c: Context, info: Info, dir: File, processId: String, onProgress: (Int) -> Unit
    ): File {
        if (info.direct != null) throw IOException("Для этого поста звук отдельно недоступен.")
        dir.mkdirs()
        cancelled.set(false)
        need(c)
        val stamp = System.currentTimeMillis()
        val req = YoutubeDLRequest(info.url)
        req.addOption("--no-playlist")
        req.addOption("--playlist-items", "1")
        req.addOption("--no-mtime")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "20")
        req.addOption("-f", "ba[ext=m4a]/ba/b")
        req.addOption("-x")
        req.addOption("--audio-format", "m4a")
        req.addOption("-o", File(dir, "dl_$stamp.%(ext)s").absolutePath)
        try {
            YoutubeDL.getInstance().execute(req, processId) { p, _, _ ->
                onProgress(p.toInt().coerceIn(0, 100))
            }
        } catch (e: Exception) {
            if (cancelled.get()) throw IOException("Отменено")
            throw IOException(friendly(e))
        }
        return pick(dir, stamp)
    }

    fun cancel(processId: String) {
        cancelled.set(true)
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Exception) {}
    }

    /** Обновляет сам yt-dlp: сайты меняются, и старая версия перестаёт открывать ссылки. */
    fun update(c: Context): String {
        need(c)
        val st = YoutubeDL.getInstance().updateYoutubeDL(
            c.applicationContext, YoutubeDL.UpdateChannel.STABLE
        )?.toString() ?: ""
        return if (st.contains("ALREADY", ignoreCase = true)) "Уже последняя версия"
        else "Движок обновлён"
    }
}
