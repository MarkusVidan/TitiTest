package com.example.tiktrim

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.io.IOException

data class Vid(
    val id: Long, val name: String, val durationMs: Long,
    val size: Long, val uri: Uri, val path: String
)

object Store {
    val VIDEOS: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    /** Папка для обрезанных видео (внутри Movies). */
    fun folder(c: Context): String =
        Prefs.str(c, "folder", "Trimmed")
            .replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifBlank { "Trimmed" }

    fun safeName(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), " ").replace(Regex("\\s+"), " ")
            .trim().take(60).ifBlank { "video" }

    private fun mimeOf(f: File) = when (f.extension.lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    /** Копирует файл в Movies/<relDir>. Вызывать НЕ из главного потока. */
    fun saveVideo(c: Context, src: File, baseName: String, relDir: String): Uri {
        val ext = src.extension.ifBlank { "mp4" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$baseName.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(src))
            put(MediaStore.MediaColumns.RELATIVE_PATH, relDir)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return copyIn(c, VIDEOS, values, src)
    }

    /** Копирует звук в Music/TikTrim. */
    fun saveAudio(c: Context, src: File, baseName: String): Uri {
        val ext = src.extension.ifBlank { "m4a" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$baseName.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, if (ext == "mp3") "audio/mpeg" else "audio/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/TikTrim")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return copyIn(c, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values, src)
    }

    private fun copyIn(c: Context, coll: Uri, values: ContentValues, src: File): Uri {
        val out = c.contentResolver.insert(coll, values)
            ?: throw IOException("Не удалось создать файл в галерее.")
        try {
            c.contentResolver.openOutputStream(out)!!.use { o ->
                src.inputStream().use { it.copyTo(o) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            c.contentResolver.update(out, values, null, null)
        } catch (e: Exception) {
            try { c.contentResolver.delete(out, null, null) } catch (_: Exception) {}
            throw e
        }
        return out
    }

    /** Видео, которые сохранило само приложение (обрезанные и скачанные). */
    fun queryOwn(c: Context, limit: Int = 200): List<Vid> {
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.RELATIVE_PATH
        )
        val out = ArrayList<Vid>()
        c.contentResolver.query(
            VIDEOS, proj,
            "${MediaStore.Video.Media.OWNER_PACKAGE_NAME} = ? AND ${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?",
            arrayOf(c.packageName, "Movies/%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cur ->
            while (cur.moveToNext() && out.size < limit) {
                val id = cur.getLong(0)
                out.add(
                    Vid(id, cur.getString(1) ?: "video", cur.getLong(2), cur.getLong(3),
                        ContentUris.withAppendedId(VIDEOS, id), cur.getString(4) ?: "")
                )
            }
        }
        return out
    }
}
