package com.example.tiktrim

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate

/** Тема (светлая/тёмная/системная) и цвет акцента. */
object Look {
    /** 0 системная, 1 светлая, 2 тёмная */
    fun nightMode(idx: Int): Int = when (idx) {
        1 -> AppCompatDelegate.MODE_NIGHT_NO
        2 -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    private val themes = intArrayOf(
        R.style.Theme_TikTrim, R.style.Theme_TikTrim_Green, R.style.Theme_TikTrim_Purple,
        R.style.Theme_TikTrim_Pink, R.style.Theme_TikTrim_Orange, R.style.Theme_TikTrim_Teal,
        R.style.Theme_TikTrim_Red
    )

    /** Цвета кружков в настройках (совпадают с colorPrimary каждой темы). */
    val swatches = intArrayOf(
        R.color.ios_blue, R.color.acc_green, R.color.acc_purple, R.color.acc_pink,
        R.color.acc_orange, R.color.acc_teal, R.color.acc_red
    )

    val names = intArrayOf(
        R.string.accent_blue, R.string.accent_green, R.string.accent_purple, R.string.accent_pink,
        R.string.accent_orange, R.string.accent_teal, R.string.accent_red
    )

    /** Вызывать в onCreate ДО super.onCreate. */
    fun applyAccent(a: Activity) {
        a.setTheme(themes[Prefs.int(a, "accent", 0).coerceIn(0, themes.size - 1)])
    }
}

/** Строки из ресурсов в любом месте приложения, с учётом выбранного языка. */
object Lang {
    fun str(c: Context, id: Int, vararg args: Any): String {
        // Активность уже получила нужный язык от AppCompat
        if (c is Activity) return c.getString(id, *args)
        val l = AppCompatDelegate.getApplicationLocales()
        if (l.isEmpty) return c.getString(id, *args)
        val cfg = Configuration(c.resources.configuration)
        cfg.setLocale(l.get(0))
        return c.createConfigurationContext(cfg).getString(id, *args)
    }
}
